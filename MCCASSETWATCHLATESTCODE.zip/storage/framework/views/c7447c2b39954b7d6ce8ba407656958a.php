<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'label' => null, 'value' => null, 'required' => false, 'placeholder' => null, 'rows' => 3, 'maxlength' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'label' => null, 'value' => null, 'required' => false, 'placeholder' => null, 'rows' => 3, 'maxlength' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php $error = $errors->first($name); ?>

<div class="w-full">
    <?php if($label): ?>
        <label for="f-<?php echo e($name); ?>" class="mb-[7px] block text-xs font-medium text-ink"><?php echo e($label); ?><?php if($required): ?> *<?php endif; ?></label>
    <?php endif; ?>
    <textarea id="f-<?php echo e($name); ?>" name="<?php echo e($name); ?>" rows="<?php echo e($rows); ?>"
              <?php if($placeholder): ?> placeholder="<?php echo e($placeholder); ?>" <?php endif; ?>
              <?php if($maxlength): ?> maxlength="<?php echo e($maxlength); ?>" <?php endif; ?>
              <?php if($required): ?> required <?php endif; ?>
              class="w-full resize-y rounded-md border bg-white p-3 text-xs leading-[1.45] text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 <?php echo e($error ? 'border-red-400' : 'border-line'); ?>"><?php echo e(old($name, $value)); ?></textarea>
    <?php if($error): ?>
        <p class="mt-1 text-[10px] text-[#b91c1c]"><?php echo e($error); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/components/textarea.blade.php ENDPATH**/ ?>