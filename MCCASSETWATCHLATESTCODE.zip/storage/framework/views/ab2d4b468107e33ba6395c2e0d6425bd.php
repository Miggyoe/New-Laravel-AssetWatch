<?php
    /** @var \App\Models\Technician|null $technician */
    $id     = $technician ? 'edit-personnel-' . $technician->id : 'add-personnel';
    $action = $technician ? route('admin.personnel.update', $technician) : route('admin.personnel.store');
    $reopen = ($openModal ?? null) === $id;   // only this dialog re-uses the submitted values after a validation error
    $val    = fn (string $key, $default = null) => $reopen ? old($key) : ($technician?->{$key} ?? $default);
    $input  = 'h-10 w-full rounded-md border bg-white px-3.5 text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/30';
    $err    = fn (string $key) => $reopen ? $errors->first($key) : null;
?>

<?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => $id,'title' => $technician ? 'Edit personnel' : 'Add personnel','subtitle' => $technician ? $technician->staff_id . ' · ' . $technician->name : 'A staff ID is assigned automatically.','width' => 560,'open' => $reopen]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($id),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($technician ? 'Edit personnel' : 'Add personnel'),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($technician ? $technician->staff_id . ' · ' . $technician->name : 'A staff ID is assigned automatically.'),'width' => 560,'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reopen)]); ?>
    <form method="POST" action="<?php echo e($action); ?>" class="flex flex-col gap-4">
        <?php echo csrf_field(); ?>
        <?php if($technician): ?> <?php echo method_field('PATCH'); ?> <?php endif; ?>
        <input type="hidden" name="_modal" value="<?php echo e($id); ?>">

        <?php $__currentLoopData = [['name', 'Full name', 'text', true], ['email', 'Institutional email', 'email', true]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, $label, $type, $required]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <label for="<?php echo e($id); ?>-<?php echo e($key); ?>" class="mb-[7px] block text-xs font-medium"><?php echo e($label); ?> *</label>
                <input id="<?php echo e($id); ?>-<?php echo e($key); ?>" type="<?php echo e($type); ?>" name="<?php echo e($key); ?>" value="<?php echo e($val($key)); ?>" required
                       class="<?php echo e($input); ?> <?php echo e($err($key) ? 'border-red-400' : 'border-line'); ?>">
                <?php if($err($key)): ?> <p class="mt-1 text-[10px] text-[#b91c1c]"><?php echo e($err($key)); ?></p> <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="flex flex-col gap-4 sm:flex-row">
            <div class="flex-1">
                <label for="<?php echo e($id); ?>-phone" class="mb-[7px] block text-xs font-medium">Phone</label>
                <input id="<?php echo e($id); ?>-phone" name="phone" value="<?php echo e($val('phone')); ?>" maxlength="30" class="<?php echo e($input); ?> border-line">
            </div>
        </div>

        <div class="flex flex-col gap-4 sm:flex-row">
            <div class="sm:w-[170px]">
                <label for="<?php echo e($id); ?>-specialty" class="mb-[7px] block text-xs font-medium">Specialty *</label>
                <input id="<?php echo e($id); ?>-specialty" name="specialty" value="<?php echo e($val('specialty')); ?>" required maxlength="60" placeholder="e.g. Carpentry"
                       class="<?php echo e($input); ?> <?php echo e($err('specialty') ? 'border-red-400' : 'border-line'); ?>">
                <?php if($err('specialty')): ?> <p class="mt-1 text-[10px] text-[#b91c1c]"><?php echo e($err('specialty')); ?></p> <?php endif; ?>
            </div>
            <div class="flex-1">
                <label for="<?php echo e($id); ?>-specialization" class="mb-[7px] block text-xs font-medium">Specialization</label>
                <input id="<?php echo e($id); ?>-specialization" name="specialization" value="<?php echo e($val('specialization')); ?>" maxlength="150" placeholder="e.g. Carpentry &amp; furniture repair"
                       class="<?php echo e($input); ?> border-line">
            </div>
        </div>

        <div class="flex flex-wrap gap-6 text-xs">
            <label class="flex items-center gap-2"><input type="checkbox" name="is_active" value="1" class="size-3.5 accent-brand"
                   <?php if($reopen ? old('is_active') : ($technician?->is_active ?? true)): echo 'checked'; endif; ?>> Account active</label>
            <label class="flex items-center gap-2"><input type="checkbox" name="is_available" value="1" class="size-3.5 accent-brand"
                   <?php if($reopen ? old('is_available') : ($technician?->is_available ?? true)): echo 'checked'; endif; ?>> Available for assignments</label>
        </div>

        <div class="flex justify-end gap-2.5">
            <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Cancel</button>
            <button type="submit" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700"><?php echo e($technician ? 'Save Changes' : 'Add Personnel'); ?></button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/personnel/_form.blade.php ENDPATH**/ ?>