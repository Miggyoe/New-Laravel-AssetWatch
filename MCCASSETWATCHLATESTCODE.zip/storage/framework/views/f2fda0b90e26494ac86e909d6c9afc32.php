
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['size' => 38]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['size' => 38]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div <?php echo e($attributes->merge(['style' => 'display:flex;align-items:center;gap:11px;min-width:0;'])); ?>>
    <div style="display:flex;flex:0 0 auto;align-items:center;justify-content:center;width:<?php echo e($size); ?>px;height:<?php echo e($size); ?>px;padding:3px;background:#fff;border-radius:8px;">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="MCC AssetWatch logo" width="<?php echo e($size); ?>" height="<?php echo e($size); ?>"
             style="display:block;width:100%;height:100%;object-fit:contain;">
    </div>
    <div style="min-width:0;line-height:1.3;white-space:nowrap;">
        <p style="margin:0;font-size:16px;font-weight:700;color:#fff;">MCC AssetWatch</p>
        <p style="margin:0;font-size:9px;font-weight:400;color:#c4d2e3;">CAMPUS FACILITIES PORTAL</p>
    </div>
</div>
<?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/components/brand.blade.php ENDPATH**/ ?>