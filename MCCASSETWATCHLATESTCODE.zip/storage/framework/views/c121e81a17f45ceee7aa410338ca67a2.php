<?php $__env->startSection('title', $report->reference_no); ?>
<?php $__env->startSection('breadcrumb', 'Incident Reports'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $RS         = \App\Enums\ReportStatus::class;
        $status     = $report->status;
        $isPending  = $status === $RS::Pending;
        $isRejected = $status === $RS::Rejected;
        $isResolved = $status === $RS::Resolved;
        $isActive   = in_array($status, [$RS::Verified, $RS::InProgress], true);
        $attachments = $report->attachments;
        $first       = $attachments->first();

        $btn     = 'flex h-9 w-full items-center justify-center rounded-md text-[11px] font-semibold transition-colors';
        $primary = "$btn bg-brand text-white hover:bg-blue-700";
        $outline = "$btn border border-line bg-white text-ink hover:bg-canvas";
        $danger  = "$btn border border-[#b91c1c] bg-white text-[#b91c1c] hover:bg-[#fef2f2]";

        $createUrl = route('admin.work-orders.index', ['report' => $report->id]);
        $orderUrl  = $workOrder ? route('admin.work-orders.show', $workOrder) : null;
    ?>

    
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-col gap-[5px] leading-[1.45]">
            <h1 class="text-[26px] font-semibold"><?php echo e($report->title); ?></h1>
            <p class="text-xs text-muted"><?php echo e($report->reference_no); ?> · Incident report details</p>
        </div>
        <div class="flex items-center gap-2.5">
            <p class="text-[11px] text-muted"><?php echo e($headerNote); ?></p>
            <a href="<?php echo e(route('admin.reports.index')); ?>" class="rounded-md bg-brand px-4 py-2.5 text-xs font-medium text-white hover:bg-blue-700">Back to Reports</a>
        </div>
    </div>

    <div class="grid grid-cols-1 gap-[22px] xl:grid-cols-[736fr_402fr]">
        
        <div class="flex min-w-0 flex-col gap-[18px]">
            <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                <div class="flex flex-wrap items-center justify-between gap-2">
                    <div class="flex flex-wrap items-center gap-2">
                        <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalb3f3930a96171a12366c9551b2dd3c07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3f3930a96171a12366c9551b2dd3c07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.priority-badge','data' => ['priority' => $report->priority]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('priority-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['priority' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->priority)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3f3930a96171a12366c9551b2dd3c07)): ?>
<?php $attributes = $__attributesOriginalb3f3930a96171a12366c9551b2dd3c07; ?>
<?php unset($__attributesOriginalb3f3930a96171a12366c9551b2dd3c07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3f3930a96171a12366c9551b2dd3c07)): ?>
<?php $component = $__componentOriginalb3f3930a96171a12366c9551b2dd3c07; ?>
<?php unset($__componentOriginalb3f3930a96171a12366c9551b2dd3c07); ?>
<?php endif; ?>
                        <?php if (! ($isPending)): ?>
                            <span class="flex items-center gap-[5px] text-[10px] text-muted"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'lock-keyhole','size' => 13]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'lock-keyhole','size' => 13]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>Report Locked</span>
                        <?php endif; ?>
                    </div>
                    <?php if($isPending): ?>
                        <button type="button" data-modal-open="edit-original" class="text-[11px] font-medium text-brand hover:underline">Edit original report</button>
                    <?php endif; ?>
                </div>

                <?php if($isRejected): ?>
                    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['tone' => 'red','icon' => 'lock-keyhole','title' => 'Report rejected — original submission preserved','body' => 'Reason: ' . $report->rejection_reason]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'red','icon' => 'lock-keyhole','title' => 'Report rejected — original submission preserved','body' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Reason: ' . $report->rejection_reason)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                <?php elseif(! $isPending): ?>
                    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['tone' => 'amber','icon' => 'lock-keyhole','title' => 'Report Locked — original submission preserved','body' => 'Description, location, and evidence are immutable. Reporter editing and deletion are disabled; authorized staff can manage workflow and notes.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'amber','icon' => 'lock-keyhole','title' => 'Report Locked — original submission preserved','body' => 'Description, location, and evidence are immutable. Reporter editing and deletion are disabled; authorized staff can manage workflow and notes.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                <?php endif; ?>

                <div class="flex flex-col gap-1.5 leading-[1.45]">
                    <p class="text-[11px] font-semibold">Incident description</p>
                    <p class="whitespace-pre-line text-xs"><?php echo e($report->description); ?></p>
                </div>

                <div class="flex flex-col gap-4 sm:flex-row sm:gap-6">
                    <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Asset category','value' => $report->category?->name ?? '—']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Asset category','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->category?->name ?? '—')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Building / Room','value' => $report->placeLabel()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Building / Room','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->placeLabel())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Submitted','value' => $report->created_at->format('j M Y · g:i A')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Submitted','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->created_at->format('j M Y · g:i A'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                </div>

                <div class="flex flex-col gap-4 sm:flex-row sm:gap-6">
                    <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Reporter','value' => ($report->reporter?->name ?? '—') . ($report->reporter?->department ? ' · ' . $report->reporter->department : '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Reporter','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($report->reporter?->name ?? '—') . ($report->reporter?->department ? ' · ' . $report->reporter->department : ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Institutional email','value' => $report->reporter?->email ?? '—']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Institutional email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->reporter?->email ?? '—')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                </div>

                
                <div class="flex flex-col gap-[9px]">
                    <div class="flex items-start justify-between text-[11px] leading-[1.45]">
                        <p class="font-semibold">Original evidence · <?php echo e($attachments->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('attachment', $attachments->count())); ?></p>
                        <?php if($first): ?>
                            <button type="button" data-modal-open="evidence-<?php echo e($first->id); ?>" class="font-medium text-brand hover:underline">Expand evidence ↗</button>
                        <?php endif; ?>
                    </div>

                    <?php if($first): ?>
                        <div class="relative w-full overflow-hidden rounded-md bg-canvas" style="height: <?php echo e($isPending ? 230 : 172); ?>px">
                            <?php if($first->previewUrl()): ?>
                                <img src="<?php echo e($first->previewUrl()); ?>" alt="<?php echo e($first->displayName()); ?>" class="size-full object-cover">
                            <?php else: ?>
                                <div class="flex size-full flex-col items-center justify-center gap-1.5 text-muted">
                                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'image','size' => 28]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'image','size' => 28]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                                    <p class="text-[11px]">Preview unavailable — open the original in Google Drive</p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="flex flex-wrap items-start justify-between gap-2 leading-[1.45]">
                            <p class="text-[10px] text-muted">
                                <?php echo e($first->displayName()); ?><?php echo e($first->sizeLabel() ? ' · ' . $first->sizeLabel() : ''); ?> · Submitted <?php echo e($report->created_at->format('j M Y')); ?>

                            </p>
                            <?php if($first->safeDriveUrl()): ?>
                                <a href="<?php echo e($first->safeDriveUrl()); ?>" target="_blank" rel="noopener noreferrer" class="text-[11px] font-medium text-brand hover:underline">Open in Google Drive ↗</a>
                            <?php endif; ?>
                        </div>

                        <?php $__currentLoopData = $attachments->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" data-modal-open="evidence-<?php echo e($extra->id); ?>" class="text-left text-[11px] font-medium text-brand hover:underline">
                                <?php echo e($extra->displayName()); ?><?php echo e($extra->sizeLabel() ? ' · ' . $extra->sizeLabel() : ''); ?> ↗
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p class="text-xs text-muted">No evidence was attached to this report.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-[18px] shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                <h2 class="text-[15px] font-semibold leading-[1.45]">Report timeline</h2>
                <div class="flex flex-col">
                    <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="leading-[1.8]">
                            <span class="text-[11px] text-teal">●&nbsp;&nbsp;</span><span class="text-[11px] font-medium"><?php echo e($event['label']); ?></span><span class="text-[10px] text-muted">&nbsp;&nbsp;—&nbsp;&nbsp;<?php echo e($event['at']->format('j M, g:i A')); ?><?php echo e($event['by'] ? ' • ' . $event['by'] : ''); ?></span>
                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        </div>

        
        <div class="flex min-w-0 flex-col gap-[18px]">
            <?php if($isResolved): ?>
                <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                    <div class="leading-[1.45]">
                        <h2 class="text-[15px] font-semibold">Resolution details</h2>
                        <p class="text-[11px] text-muted">Repair reviewed and closed<?php echo e($closedBy ? ' by ' . $closedBy->name : ''); ?></p>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['tone' => 'teal','icon' => 'circle-check','title' => 'Repair completed and verified']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'teal','icon' => 'circle-check','title' => 'Repair completed and verified']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Completed','value' => ($report->resolved_at ?? $report->updated_at)->format('j M Y · g:i A'),'grow' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Completed','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($report->resolved_at ?? $report->updated_at)->format('j M Y · g:i A')),'grow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                    <?php if($workOrder): ?>
                        <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Work order / Technician','value' => $workOrder->reference_no . ' · ' . $workOrder->technician?->name,'grow' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Work order / Technician','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($workOrder->reference_no . ' · ' . $workOrder->technician?->name),'grow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                    <?php endif; ?>
                    <?php if($resolutionNotes): ?>
                        <p class="whitespace-pre-line text-xs leading-[1.45]"><?php echo e($resolutionNotes); ?></p>
                    <?php endif; ?>
                    <?php if($workOrder?->evidence_url && str_starts_with($workOrder->evidence_url, 'https://')): ?>
                        <a href="<?php echo e($workOrder->evidence_url); ?>" target="_blank" rel="noopener noreferrer" class="text-[11px] font-medium text-brand hover:underline">View completion evidence ↗</a>
                    <?php endif; ?>
                    <?php if($orderUrl): ?>
                        <a href="<?php echo e($orderUrl); ?>" class="<?php echo e($outline); ?>">View Work Order</a>
                    <?php endif; ?>
                </section>
            <?php elseif($isRejected): ?>
                <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                    <div class="leading-[1.45]">
                        <h2 class="text-[15px] font-semibold">Rejection details</h2>
                        <p class="text-[11px] text-muted">Rejected<?php echo e($rejectedBy ? ' by ' . $rejectedBy->name : ''); ?><?php echo e($report->rejected_at ? ' · ' . $report->rejected_at->format('j M Y, g:i A') : ''); ?></p>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Reason','value' => $report->rejection_reason ?? '—','grow' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Reason','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->rejection_reason ?? '—'),'grow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                    <div class="leading-[1.6]">
                        <p class="text-[10px] text-muted">Explanation sent to the reporter</p>
                        <p class="whitespace-pre-line text-xs"><?php echo e($report->rejection_explanation ?? '—'); ?></p>
                    </div>
                </section>
            <?php else: ?>
                <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                    <div class="leading-[1.45]">
                        <h2 class="text-[15px] font-semibold">Administrative actions</h2>
                        <p class="text-[11px] text-muted">Administrator access · Workflow controls</p>
                    </div>

                    <?php if($isPending): ?>
                        <p class="text-xs leading-[1.45] text-muted">Review the original report and evidence before verifying or rejecting this incident.</p>

                        <form method="POST" action="<?php echo e(route('admin.reports.verify', $report)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="<?php echo e($primary); ?>">Verify Report</button>
                        </form>
                        <button type="button" data-modal-open="reject-report" class="<?php echo e($danger); ?>">Reject Report</button>
                        <button type="button" data-modal-open="change-priority" class="<?php echo e($outline); ?>">Change Priority</button>

                        <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['tone' => 'blue','icon' => 'info','title' => 'Original report is editable','body' => 'Authorized administrators may correct information before verification.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'blue','icon' => 'info','title' => 'Original report is editable','body' => 'Authorized administrators may correct information before verification.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                    <?php else: ?>
                        <?php if($orderUrl): ?>
                            <a href="<?php echo e($orderUrl); ?>" class="<?php echo e($primary); ?>">View Work Order</a>
                            <a href="<?php echo e($orderUrl); ?>" class="<?php echo e($outline); ?>">Assign Maintenance Personnel</a>
                        <?php else: ?>
                            <a href="<?php echo e($createUrl); ?>" class="<?php echo e($primary); ?>">Create Work Order</a>
                            <a href="<?php echo e($createUrl); ?>" class="<?php echo e($outline); ?>">Assign Maintenance Personnel</a>
                        <?php endif; ?>

                        <?php if($nextStatus): ?>
                            <button type="button" data-modal-open="change-status" class="<?php echo e($outline); ?>">Update Status</button>
                        <?php endif; ?>
                        <button type="button" data-modal-open="change-priority" class="<?php echo e($outline); ?>">Change Priority</button>

                        <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Assigned technician','value' => $workOrder ? $workOrder->technician?->label() : 'Not yet assigned','grow' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Assigned technician','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($workOrder ? $workOrder->technician?->label() : 'Not yet assigned'),'grow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Target completion','value' => $workOrder ? $workOrder->target_at->format('j M Y · g:i A') : 'Set when creating a work order','grow' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Target completion','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($workOrder ? $workOrder->target_at->format('j M Y · g:i A') : 'Set when creating a work order'),'grow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                    <?php endif; ?>
                </section>
            <?php endif; ?>

            <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                <h2 class="text-[15px] font-semibold leading-[1.45]">Maintenance notes</h2>

                <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-md bg-canvas p-3 leading-[1.45]">
                        <p class="whitespace-pre-line text-xs"><?php echo e($note->body); ?></p>
                        <p class="mt-1 text-[10px] text-muted"><?php echo e($note->user?->name ?? 'Administrator'); ?> · <?php echo e($note->created_at->format('j M, g:i A')); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <form method="POST" action="<?php echo e(route('admin.reports.notes.store', $report)); ?>" class="flex flex-col gap-3.5">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_modal" value="">
                    <?php if (isset($component)) { $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.textarea','data' => ['name' => 'body','label' => 'Internal note','rows' => '3','maxlength' => '1000','placeholder' => 'Add context for the maintenance team...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'body','label' => 'Internal note','rows' => '3','maxlength' => '1000','placeholder' => 'Add context for the maintenance team...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $attributes = $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $component = $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>
                    <button type="submit" class="<?php echo e($outline); ?>">Add Note</button>
                </form>
                <p class="text-[10px] leading-[1.45] text-muted">Notes are timestamped and visible to authorized staff. They do not modify the original submission.</p>
            </section>
        </div>
    </div>

    

    <?php if($isPending): ?>
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'reject-report','title' => 'Reject this report?','subtitle' => $report->reference_no . ' · ' . $report->title,'open' => $openModal === 'reject-report']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'reject-report','title' => 'Reject this report?','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->reference_no . ' · ' . $report->title),'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($openModal === 'reject-report')]); ?>
            <form method="POST" action="<?php echo e(route('admin.reports.reject', $report)); ?>" class="flex flex-col gap-5">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_modal" value="reject-report">
                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['tone' => 'amber','icon' => 'lock-keyhole','title' => 'This action notifies the reporter','body' => 'A rejection reason is required and will be recorded in the audit log.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'amber','icon' => 'lock-keyhole','title' => 'This action notifies the reporter','body' => 'A rejection reason is required and will be recorded in the audit log.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'rejection_reason','label' => 'Rejection reason','required' => true,'submit' => false,'width' => 'w-full','options' => $options['rejection'],'selected' => old('rejection_reason', 'Duplicate of an existing report')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'rejection_reason','label' => 'Rejection reason','required' => true,'submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'width' => 'w-full','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['rejection']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('rejection_reason', 'Duplicate of an existing report'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.textarea','data' => ['name' => 'rejection_explanation','label' => 'Explanation for reporter *','rows' => '3','maxlength' => '1000','placeholder' => 'Tell the reporter why this report cannot proceed.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'rejection_explanation','label' => 'Explanation for reporter *','rows' => '3','maxlength' => '1000','placeholder' => 'Tell the reporter why this report cannot proceed.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $attributes = $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $component = $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>
                <div class="flex justify-end gap-2.5">
                    <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Keep Report</button>
                    <button type="submit" class="h-9 rounded-md bg-[#b91c1c] px-4 text-[11px] font-semibold text-white hover:bg-[#991b1b]">Reject Report</button>
                </div>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'edit-original','title' => 'Edit original report','subtitle' => $report->reference_no . ' · Before verification','width' => 640,'open' => $openModal === 'edit-original']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'edit-original','title' => 'Edit original report','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->reference_no . ' · Before verification'),'width' => 640,'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($openModal === 'edit-original')]); ?>
            <form method="POST" action="<?php echo e(route('admin.reports.update', $report)); ?>" class="flex flex-col gap-5">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="_modal" value="edit-original">
                <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'title','label' => 'Incident title','value' => $report->title,'required' => true,'maxlength' => '150']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Incident title','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->title),'required' => true,'maxlength' => '150']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.textarea','data' => ['name' => 'description','label' => 'Incident description','value' => $report->description,'rows' => '4','required' => true,'maxlength' => '3000']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'description','label' => 'Incident description','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->description),'rows' => '4','required' => true,'maxlength' => '3000']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $attributes = $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $component = $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>
                <div class="flex flex-col gap-4 sm:flex-row">
                    <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'category_id','label' => 'Asset category','required' => true,'submit' => false,'width' => 'w-full sm:flex-1','options' => $options['category'],'selected' => old('category_id', $report->category_id)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'category_id','label' => 'Asset category','required' => true,'submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'width' => 'w-full sm:flex-1','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['category']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('category_id', $report->category_id))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'location_id','label' => 'Building / Room','required' => true,'submit' => false,'width' => 'w-full sm:flex-1','options' => $options['location'],'selected' => old('location_id', $report->location_id)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'location_id','label' => 'Building / Room','required' => true,'submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'width' => 'w-full sm:flex-1','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['location']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('location_id', $report->location_id))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                </div>
                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['tone' => 'blue','icon' => 'info','title' => 'Corrections are recorded','body' => 'After verification the original report becomes read-only.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'blue','icon' => 'info','title' => 'Corrections are recorded','body' => 'After verification the original report becomes read-only.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                <div class="flex justify-end gap-2.5">
                    <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Cancel</button>
                    <button type="submit" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700">Save Changes</button>
                </div>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if(! $isResolved && ! $isRejected): ?>
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'change-priority','title' => 'Change priority','subtitle' => $report->reference_no . ' · ' . $report->title,'width' => 480,'open' => $openModal === 'change-priority']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'change-priority','title' => 'Change priority','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->reference_no . ' · ' . $report->title),'width' => 480,'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($openModal === 'change-priority')]); ?>
            <form method="POST" action="<?php echo e(route('admin.reports.priority', $report)); ?>" class="flex flex-col gap-5">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="_modal" value="change-priority">
                <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'priority','label' => 'Priority','required' => true,'submit' => false,'width' => 'w-full','options' => $options['priority'],'selected' => old('priority', $report->priority->value)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'priority','label' => 'Priority','required' => true,'submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'width' => 'w-full','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['priority']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('priority', $report->priority->value))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                <div class="flex justify-end gap-2.5">
                    <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Cancel</button>
                    <button type="submit" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700">Save Priority</button>
                </div>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if($nextStatus): ?>
        <?php $resolving = $nextStatus === $RS::Resolved; ?>
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'change-status','title' => 'Confirm status change','subtitle' => $report->reference_no . ' · ' . $report->title,'open' => $openModal === 'change-status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'change-status','title' => 'Confirm status change','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->reference_no . ' · ' . $report->title),'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($openModal === 'change-status')]); ?>
            <form method="POST" action="<?php echo e(route('admin.reports.status', $report)); ?>" class="flex flex-col gap-5">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="_modal" value="change-status">

                <div class="flex items-center gap-4">
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => 14,'class' => 'text-muted']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => 14,'class' => 'text-muted']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $nextStatus]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nextStatus)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                </div>

                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['tone' => 'blue','icon' => 'info','title' => 'Original report remains locked','body' => 'Only the workflow status and resolution notes will change.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'blue','icon' => 'info','title' => 'Original report remains locked','body' => 'Only the workflow status and resolution notes will change.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.textarea','data' => ['name' => 'notes','label' => $resolving ? 'Resolution notes *' : 'Status notes *','rows' => '3','maxlength' => '1000','placeholder' => $resolving ? 'Describe the repair that was completed.' : 'Why is the status changing?']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'notes','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resolving ? 'Resolution notes *' : 'Status notes *'),'rows' => '3','maxlength' => '1000','placeholder' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resolving ? 'Describe the repair that was completed.' : 'Why is the status changing?')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $attributes = $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $component = $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>

                <?php if($resolving): ?>
                    <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'completed_at','type' => 'datetime-local','label' => 'Completion date','required' => true,'value' => now()->format('Y-m-d\TH:i')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'completed_at','type' => 'datetime-local','label' => 'Completion date','required' => true,'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(now()->format('Y-m-d\TH:i'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                <?php endif; ?>

                <div class="flex justify-end gap-2.5">
                    <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Cancel</button>
                    <button type="submit" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700">Confirm Status Change</button>
                </div>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php endif; ?>

    
    <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'evidence-' . $file->id,'title' => 'Evidence viewer','subtitle' => $report->reference_no . ' · Original submitted evidence · Read-only','width' => 900]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('evidence-' . $file->id),'title' => 'Evidence viewer','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($report->reference_no . ' · Original submitted evidence · Read-only'),'width' => 900]); ?>
            <div class="w-full overflow-hidden rounded-md bg-canvas" style="height: 475px">
                <?php if($file->previewUrl()): ?>
                    <img src="<?php echo e($file->previewUrl()); ?>" alt="<?php echo e($file->displayName()); ?>" class="size-full object-cover">
                <?php else: ?>
                    <div class="flex size-full flex-col items-center justify-center gap-2 text-muted">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'image','size' => 40]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'image','size' => 40]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <p class="text-xs">Preview unavailable — open the original in Google Drive</p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div class="leading-[1.45]">
                    <p class="text-xs font-medium"><?php echo e($file->displayName()); ?></p>
                    <p class="text-[11px] text-muted">
                        <?php echo e($report->reporter?->name ?? 'Reporter'); ?> · <?php echo e($report->created_at->format('j M Y, g:i A')); ?><?php echo e($file->sizeLabel() ? ' · ' . $file->sizeLabel() : ''); ?>

                    </p>
                </div>
                <?php if($file->safeDriveUrl()): ?>
                    <a href="<?php echo e($file->safeDriveUrl()); ?>" target="_blank" rel="noopener noreferrer"
                       class="flex h-9 items-center rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Open in Google Drive</a>
                <?php endif; ?>
                <button type="button" data-modal-close class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700">Close</button>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/reports/show.blade.php ENDPATH**/ ?>