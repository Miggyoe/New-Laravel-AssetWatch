<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('breadcrumb', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $hour = now()->hour;
        $greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');

        // "ETHAN MIGUEL PATIO" -> "Ethan Miguel" (everything except the last word; one-word names stay whole)
        $nameParts = preg_split('/\s+/', trim((string) auth()->user()->name)) ?: [];
        if (count($nameParts) > 1) {
            array_pop($nameParts);
        }
        $adminName = implode(' ', $nameParts);
        if ($adminName === mb_strtoupper($adminName)) {
            $adminName = \Illuminate\Support\Str::title(mb_strtolower($adminName));
        }
        $adminName = $adminName ?: 'Administrator';
        $reportsUrl = Route::has('admin.reports.index') ? route('admin.reports.index') : '#';
        $logUrl = Route::has('admin.activity-logs') ? route('admin.activity-logs') : '#';
    ?>

    
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-col gap-[5px]">
            <h1 class="text-[26px] font-semibold leading-[1.45]"><?php echo e($greeting); ?>, <?php echo e($adminName); ?></h1>
            <p class="text-xs text-muted">Monitor campus facility reports and maintenance activities in one place.</p>
        </div>
        <div class="flex items-center gap-2.5">
            <p class="text-[11px] text-muted"><?php echo e(now()->format('D, j F Y')); ?></p>
            <a href="<?php echo e($reportsUrl); ?>" class="rounded-md bg-brand px-4 py-2.5 text-xs font-medium text-white hover:bg-blue-700">View All Reports</a>
        </div>
    </div>

    
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['label' => 'Total Reports','value' => $stats['total'],'note' => 'Current snapshot','icon' => 'clipboard-list','iconClass' => 'text-brand']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Total Reports','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['total']),'note' => 'Current snapshot','icon' => 'clipboard-list','icon-class' => 'text-brand']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['label' => 'Pending Verification','value' => $stats['pending'],'note' => 'Awaiting review','icon' => 'clock-3','iconClass' => 'text-[#a16207]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Pending Verification','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['pending']),'note' => 'Awaiting review','icon' => 'clock-3','icon-class' => 'text-[#a16207]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['label' => 'In Progress','value' => $stats['in_progress'],'note' => 'Active repairs','icon' => 'wrench','iconClass' => 'text-brand']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'In Progress','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['in_progress']),'note' => 'Active repairs','icon' => 'wrench','icon-class' => 'text-brand']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['label' => 'Resolved Reports','value' => $stats['resolved_ytd'],'note' => 'Year to date','icon' => 'circle-check','iconClass' => 'text-teal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Resolved Reports','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['resolved_ytd']),'note' => 'Year to date','icon' => 'circle-check','icon-class' => 'text-teal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
    </div>

    
    <div class="grid grid-cols-1 gap-[18px] xl:grid-cols-[680fr_462fr]">
        
        <section class="flex min-w-0 flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
            <div class="flex items-center justify-between gap-3">
                <div class="flex flex-col gap-[3px]">
                    <h2 class="text-[15px] font-semibold leading-[1.45]">Reports overview</h2>
                    <p class="text-[10px] text-muted">Reports received and resolved · <?php echo e($trend['period']); ?></p>
                </div>
                <form method="GET" class="relative">
                    <select name="range" onchange="this.form.submit()"
                            class="appearance-none rounded-md border border-line bg-white py-2.5 pl-3.5 pr-9 text-xs focus:outline-none focus:ring-2 focus:ring-brand/30">
                        <?php $__currentLoopData = [7 => 'Last 7 days', 14 => 'Last 14 days', 30 => 'Last 30 days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($range === $value): echo 'selected'; endif; ?>><?php echo e($text); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </form>
            </div>

            <div class="flex gap-5 text-[10px] text-muted">
                <span class="flex items-center gap-1.5"><span class="size-2 rounded bg-brand"></span>Received</span>
                <span class="flex items-center gap-1.5"><span class="size-2 rounded bg-teal"></span>Resolved</span>
            </div>

            <svg viewBox="0 0 640 150" class="h-auto w-full" role="img"
                 aria-label="Reports received and resolved per day, <?php echo e($trend['period']); ?>">
                <?php $__currentLoopData = $trend['ticks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $gy = 115 - ($tick / $trend['top']) * 105; ?>
                    <line x1="30" x2="640" y1="<?php echo e($gy); ?>" y2="<?php echo e($gy); ?>" stroke="#e2e8f0" />
                    <text x="0" y="<?php echo e($gy + 3); ?>" font-size="9" fill="#64748b"><?php echo e($tick); ?></text>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <polyline points="<?php echo e($trend['received_points']); ?>" fill="none" stroke="#2563eb" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" />
                <polyline points="<?php echo e($trend['resolved_points']); ?>" fill="none" stroke="#0f9d8a" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" />

                <?php $__currentLoopData = $trend['labels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($label['show']): ?>
                        <text x="<?php echo e($label['x']); ?>" y="140" text-anchor="middle" font-size="9" fill="#64748b"><?php echo e($label['text']); ?></text>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </svg>
        </section>

        
        <section class="flex min-w-0 flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
            <div>
                <h2 class="text-[15px] font-semibold leading-[1.45]">Report status distribution</h2>
                <p class="text-[11px] leading-[1.45] text-muted">Current snapshot · all <?php echo e(number_format($total)); ?> reports</p>
            </div>

            <div class="flex flex-wrap items-center gap-6">
                <div class="relative size-[156px] shrink-0">
                    <svg viewBox="0 0 156 156" class="size-full -rotate-90" aria-hidden="true">
                        <circle cx="78" cy="78" r="69" fill="none" stroke="#e2e8f0" stroke-width="18" />
                        <?php $__currentLoopData = $donut['segments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($segment['count'] > 0): ?>
                                <circle cx="78" cy="78" r="69" fill="none"
                                        stroke="<?php echo e($segment['status']->color()); ?>" stroke-width="18"
                                        stroke-dasharray="<?php echo e($segment['dash']); ?> <?php echo e($donut['circumference']); ?>"
                                        stroke-dashoffset="<?php echo e($segment['offset']); ?>" />
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </svg>
                    <div class="absolute inset-0 flex flex-col items-center justify-center">
                        <p class="text-[28px] font-semibold leading-[1.45]"><?php echo e(number_format($total)); ?></p>
                        <p class="text-[10px] text-muted">Total reports</p>
                    </div>
                </div>

                <ul class="flex min-w-[140px] flex-1 flex-col gap-[11px]">
                    <?php $__currentLoopData = $donut['segments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex items-center justify-between text-[11px] leading-[1.45]">
                            <span class="flex items-center gap-[7px] text-muted">
                                <span class="size-[7px] rounded-full" style="background: <?php echo e($segment['status']->color()); ?>"></span>
                                <?php echo e($segment['status']->label()); ?>

                            </span>
                            <span class="font-semibold"><?php echo e(number_format($segment['count'])); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </section>
    </div>

    
    <div class="grid grid-cols-1 gap-[18px] xl:grid-cols-[844fr_298fr]">
        <section class="flex min-w-0 flex-col rounded-[10px] border border-line bg-white shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
            <div class="flex items-start justify-between px-[18px] pb-3.5 pt-4">
                <h2 class="text-[15px] font-semibold leading-[1.45]">Recent incident reports</h2>
                <a href="<?php echo e($reportsUrl); ?>" class="text-[11px] font-medium text-brand hover:underline">View all reports →</a>
            </div>

            <div class="flex-1 overflow-x-auto">
                <table class="h-full w-full min-w-[760px] text-left">
                    <thead>
                        <tr class="h-[43px] bg-canvas text-[10px] font-semibold text-muted">
                            <th class="pl-4 pr-2 font-semibold">Report ID</th>
                            <th class="px-2 font-semibold">Incident title</th>
                            <th class="px-2 font-semibold">Building / Room</th>
                            <th class="px-2 font-semibold">Category</th>
                            <th class="px-2 font-semibold">Reported</th>
                            <th class="px-2 font-semibold">Priority</th>
                            <th class="px-2 font-semibold">Status</th>
                            <th class="pl-2 pr-4 font-semibold">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-[11px]">
                        <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="h-12 border-b border-line last:border-b-0">
                                <td class="pl-4 pr-2 font-medium text-brand"><?php echo e($report->reference_no); ?></td>
                                <td class="px-2"><?php echo e($report->title); ?></td>
                                <td class="px-2"><?php echo e($report->placeLabel()); ?></td>
                                <td class="px-2"><?php echo e($report->category?->name ?? '—'); ?></td>
                                <td class="whitespace-nowrap px-2"><?php echo e($report->created_at->format('j M Y')); ?></td>
                                <td class="px-2">
                                    <span class="inline-flex rounded-full px-2 py-1 text-[10px] font-semibold <?php echo e($report->priority->badge()); ?>"><?php echo e($report->priority->label()); ?></span>
                                </td>
                                <td class="px-2">
                                    <span class="inline-flex whitespace-nowrap rounded-full px-2 py-1 text-[10px] font-semibold <?php echo e($report->status->badge()); ?>"><?php echo e($report->status->label()); ?></span>
                                </td>
                                <td class="whitespace-nowrap pl-2 pr-4 font-medium text-brand">
                                    <a href="<?php echo e(Route::has('admin.reports.show') ? route('admin.reports.show', $report) : '#'); ?>" class="hover:underline">View Details</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="px-4 py-10 text-center text-xs text-muted">No incident reports have been submitted yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <div class="flex min-w-0 flex-col gap-[18px]">
        <section class="flex min-w-0 flex-col gap-3.5 rounded-[10px] border border-line bg-white p-[18px] shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
            <h2 class="text-[15px] font-semibold leading-[1.45]">Maintenance activity</h2>

            <ul class="flex flex-col gap-[19px]">
                <?php $__empty_1 = true; $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="flex items-start gap-2.5">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $event->icon(),'size' => 16,'class' => 'text-teal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->icon()),'size' => 16,'class' => 'text-teal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <div class="flex min-w-0 flex-1 flex-col gap-1 leading-[1.45]">
                            <p class="text-[11px] font-medium"><?php echo e($event->headline()); ?></p>
                            <p class="text-[10px] text-muted"><?php echo e($event->report?->reference_no); ?> · <?php echo e($event->when()); ?></p>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="text-[11px] text-muted">No activity yet.</li>
                <?php endif; ?>
            </ul>

            <a href="<?php echo e($logUrl); ?>" class="text-[11px] font-medium text-brand hover:underline">View activity log →</a>
        </section>

        
        <section class="flex min-w-0 flex-col gap-3.5 rounded-[10px] border border-line bg-white p-[18px] shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
            <div class="flex items-start justify-between gap-2">
                <div class="leading-[1.45]">
                    <h2 class="text-[15px] font-semibold">Technician workload</h2>
                    <p class="text-[10px] text-muted">Open work orders per technician</p>
                </div>
                <?php if($workload['atCapacity'] > 0): ?>
                    <span class="shrink-0 rounded-full bg-[#fff7e0] px-2 py-1 text-[10px] font-semibold text-[#a16207]"><?php echo e($workload['atCapacity']); ?> at capacity</span>
                <?php endif; ?>
            </div>

            <ul class="flex flex-col gap-3">
                <?php $__empty_1 = true; $__currentLoopData = $workload['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $open  = (int) $tech->active_orders_count;
                        $limit = max(1, $workload['threshold']);
                        $width = $open === 0 ? 0 : max(6, min(100, (int) round($open / $limit * 100)));
                        $bar   = ! $tech->is_available ? 'bg-slate-300' : ($open >= $limit ? 'bg-[#b91c1c]' : ($open >= $limit * 0.7 ? 'bg-[#a16207]' : 'bg-teal'));
                        $profile = Route::has('admin.personnel.show') ? route('admin.personnel.show', $tech) : '#';
                    ?>
                    <li class="flex flex-col gap-1.5">
                        <div class="flex items-center justify-between gap-2 text-[11px]">
                            <a href="<?php echo e($profile); ?>" class="min-w-0 truncate hover:text-brand">
                                <?php echo e($tech->name); ?> <span class="text-muted">· <?php echo e($tech->specialty); ?></span>
                            </a>
                            <span class="shrink-0 font-semibold">
                                <?php if (! ($tech->is_available)): ?> <span class="mr-1 font-normal text-muted">Unavailable ·</span> <?php endif; ?>
                                <?php echo e($open); ?> active <?php echo e(\Illuminate\Support\Str::plural('task', $open)); ?>

                            </span>
                        </div>
                        <div class="h-[5px] rounded-full bg-[#e2e8f0]"><div class="h-full rounded-full <?php echo e($bar); ?>" style="width: <?php echo e($width); ?>%"></div></div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="text-[11px] text-muted">No active maintenance personnel yet.</li>
                <?php endif; ?>
            </ul>

            <div class="flex items-center justify-between text-[11px]">
                <a href="<?php echo e(Route::has('admin.personnel.index') ? route('admin.personnel.index') : '#'); ?>" class="font-medium text-brand hover:underline">View all personnel →</a>
                <span class="text-[10px] text-muted">Capacity: <?php echo e($workload['threshold']); ?> open orders</span>
            </div>
        </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>