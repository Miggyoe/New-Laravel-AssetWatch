
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'options', 'selected' => null, 'width' => 'w-full sm:w-[174px]', 'submit' => true, 'label' => null, 'required' => false, 'id' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'options', 'selected' => null, 'width' => 'w-full sm:w-[174px]', 'submit' => true, 'label' => null, 'required' => false, 'id' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $fieldId = $id ?? 'f-' . $name . '-' . \Illuminate\Support\Str::random(4);
    $error   = $submit ? null : $errors->first($name); // filter dropdowns share names with form fields
?>

<div class="<?php echo e($width); ?>">
    <?php if($label): ?>
        <label for="<?php echo e($fieldId); ?>" class="mb-[7px] block text-xs font-medium text-ink"><?php echo e($label); ?><?php if($required): ?> *<?php endif; ?></label>
    <?php endif; ?>

    <div class="relative">
        <select id="<?php echo e($fieldId); ?>" name="<?php echo e($name); ?>"
                <?php if($submit): ?> onchange="this.form.submit()" <?php endif; ?>
                <?php if($required): ?> required <?php endif; ?>
                class="h-10 w-full appearance-none rounded-md border bg-white pl-3.5 pr-9 text-xs text-ink focus:outline-none focus:ring-2 focus:ring-brand/30 <?php echo e($error ? 'border-red-400' : 'border-line'); ?>">
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>" <?php if((string) $selected === (string) $value): echo 'selected'; endif; ?>><?php echo e($text); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-ink']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-ink']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
    </div>

    <?php if($error): ?>
        <p class="mt-1 text-[10px] text-[#b91c1c]"><?php echo e($error); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/components/select.blade.php ENDPATH**/ ?>