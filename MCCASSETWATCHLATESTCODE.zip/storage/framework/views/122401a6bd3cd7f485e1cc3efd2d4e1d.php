<?php $__env->startSection('title', $building->name); ?>
<?php $__env->startSection('breadcrumb', 'Campus Locations'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $heads = ['Floor', 'Room code', 'Room name', 'Type', 'Reported incidents', 'Notes', 'Actions'];
        $pill  = 'inline-flex h-[23px] items-center whitespace-nowrap rounded-full px-2 text-[10px] font-semibold';
        $link  = 'font-medium text-brand hover:underline';
        $active = $building->is_active ?? true;
    ?>

    
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-col gap-[5px] leading-[1.45]">
            <h1 class="text-[26px] font-semibold"><?php echo e($building->name); ?></h1>
            <p class="text-xs text-muted">
                Rooms and details · <?php echo e(number_format($totals['rooms'])); ?> <?php echo e(\Illuminate\Support\Str::plural('room', $totals['rooms'])); ?> on <?php echo e($totals['floors'] ?: 'no'); ?> <?php echo e(\Illuminate\Support\Str::plural('floor', $totals['floors'])); ?>

                · <?php echo e(number_format($totals['reports'])); ?> reported <?php echo e(\Illuminate\Support\Str::plural('incident', $totals['reports'])); ?>

                <?php if (! ($active)): ?> · <span class="font-medium">Inactive</span> <?php endif; ?>
            </p>
        </div>
        <div class="flex items-center gap-2.5">
            <a href="<?php echo e(route('admin.locations.index')); ?>" class="flex h-9 items-center rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Back to Campus Locations</a>
            <button type="button" data-modal-open="add-room" class="rounded-md bg-brand px-4 py-2.5 text-xs font-medium text-white hover:bg-blue-700">Add Room</button>
        </div>
    </div>

    <form method="GET" action="<?php echo e(route('admin.locations.show', $building)); ?>"
          class="rounded-[10px] border border-line bg-white shadow-[0_2px_3px_rgba(23,54,93,0.02)]">

        <div class="flex flex-wrap items-center gap-3 p-[18px]">
            <div class="relative w-full sm:w-[260px]">
                <input type="search" name="q" value="<?php echo e($filters['q']); ?>" placeholder="Search room code or name"
                       class="h-10 w-full rounded-md border border-line bg-white pl-3.5 pr-10 text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/30">
                <button type="submit" class="absolute right-3 top-1/2 -translate-y-1/2 text-ink" aria-label="Search"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','size' => 16]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','size' => 16]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
            </div>
            <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'type','options' => $options['type'],'selected' => $filters['type'],'width' => 'w-full sm:w-[160px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'type','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['type']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['type']),'width' => 'w-full sm:w-[160px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'floor','options' => $options['floor'],'selected' => $filters['floor'],'width' => 'w-full sm:w-[190px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'floor','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['floor']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['floor']),'width' => 'w-full sm:w-[190px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
            <a href="<?php echo e(route('admin.locations.show', $building)); ?>" class="flex h-9 items-center rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Reset filters</a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full min-w-[900px] table-fixed text-left">
                <colgroup>
                    <col class="w-[150px]"><col class="w-[130px]"><col><col class="w-[120px]"><col class="w-[130px]"><col class="w-[210px]"><col class="w-[120px]">
                </colgroup>
                <thead>
                    <tr class="h-[43px] bg-canvas text-[10px] font-semibold text-muted">
                        <?php $__currentLoopData = $heads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="<?php echo e($i === 0 ? 'pl-4 pr-2' : 'px-2'); ?> font-semibold"><?php echo e($head); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <?php if($rooms->isNotEmpty()): ?>
                    <tbody class="text-[11px]">
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="h-12 border-b border-line last:border-b-0 hover:bg-canvas/60">
                                <td class="pl-4 pr-2 leading-[1.4]"><?php echo e($room->floor ?: '—'); ?></td>
                                <td class="px-2 font-medium"><?php echo e($room->code ?: '—'); ?></td>
                                <td class="px-2 py-1.5 leading-[1.4]"><?php echo e($room->name); ?></td>
                                <td class="px-2"><span class="<?php echo e($pill); ?> <?php echo e($room->typeBadge()); ?>"><?php echo e($room->type ?: 'Other'); ?></span></td>
                                <td class="px-2"><?php echo e(number_format($room->reports_count)); ?></td>
                                <td class="px-2 leading-[1.4] text-muted"><?php echo e($room->notes ?: '—'); ?></td>
                                <td class="whitespace-nowrap px-2">
                                    <button type="button" data-modal-open="edit-room-<?php echo e($room->id); ?>" class="<?php echo e($link); ?>">Edit</button>
                                    <span class="text-brand"> · </span>
                                    <button type="submit" form="delete-room-<?php echo e($room->id); ?>" class="font-medium text-[#b91c1c] hover:underline">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                <?php endif; ?>
            </table>
        </div>

        <?php if($rooms->isEmpty()): ?>
            <div class="flex min-h-[220px] flex-col items-center justify-center gap-3 px-6 py-10 text-center">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search-x','size' => 30,'class' => 'text-muted']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search-x','size' => 30,'class' => 'text-muted']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                <p class="text-base font-semibold leading-[1.45]"><?php echo e($hasFilters ? 'No rooms match your filters' : 'No rooms yet'); ?></p>
                <p class="text-xs text-muted"><?php echo e($hasFilters ? 'Try another keyword or reset your filters.' : 'Add the rooms of this building so reports can point to them.'); ?></p>
            </div>
        <?php else: ?>
            <p class="px-4 py-3.5 text-[11px] text-muted">Showing <?php echo e(number_format($rooms->count())); ?> of <?php echo e(number_format($totals['rooms'])); ?> <?php echo e(\Illuminate\Support\Str::plural('room', $totals['rooms'])); ?></p>
        <?php endif; ?>
    </form>

    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['tone' => 'blue','icon' => 'info','title' => 'Rooms with reports cannot be deleted','body' => 'Existing reports and work orders keep their original room. To stop new reports for a whole building, deactivate the building instead.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'blue','icon' => 'info','title' => 'Rooms with reports cannot be deleted','body' => 'Existing reports and work orders keep their original room. To stop new reports for a whole building, deactivate the building instead.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

    
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form id="delete-room-<?php echo e($room->id); ?>" method="POST" action="<?php echo e(route('admin.locations.rooms.destroy', [$building, $room])); ?>" class="hidden"
              onsubmit="return confirm('Delete <?php echo e(addslashes($room->fullLabel())); ?>? This cannot be undone.')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $__env->make('admin.locations._room-form', ['room' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('admin.locations._room-form', ['room' => $room], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/locations/show.blade.php ENDPATH**/ ?>