<?php $__env->startSection('title', $order->reference_no); ?>
<?php $__env->startSection('breadcrumb', 'Work Orders'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $report      = $order->report;
        $reportUrl   = Route::has('admin.reports.show') ? route('admin.reports.show', $report) : null;
        $profileUrl  = Route::has('admin.personnel.show') ? route('admin.personnel.show', $order->technician) : '#';
        $isCompleted = $order->status === \App\Enums\WorkOrderStatus::Completed;
        $canReassign = $order->status !== \App\Enums\WorkOrderStatus::Cancelled;

        $evidenceHost  = $order->evidence_url ? parse_url($order->evidence_url, PHP_URL_HOST) : null;
        $evidenceOk    = $order->evidence_url && str_starts_with($order->evidence_url, 'https://');
        $evidenceSource = $evidenceHost && str_contains($evidenceHost, 'drive.google.com') ? 'Google Drive' : ($evidenceHost ?: 'Link');
    ?>

    
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-col gap-[5px] leading-[1.45]">
            <h1 class="text-[26px] font-semibold"><?php echo e($order->title); ?></h1>
            <p class="text-xs text-muted">
                <?php echo e($order->reference_no); ?> · Linked incident
                <?php if($reportUrl): ?> <a href="<?php echo e($reportUrl); ?>" class="font-medium text-brand hover:underline"><?php echo e($report->reference_no); ?></a>
                <?php else: ?> <?php echo e($report->reference_no); ?> <?php endif; ?>
            </p>
        </div>
        <div class="flex items-center gap-2.5">
            <p class="text-[11px] text-muted">Authorized administrator action</p>
            <?php if($canReassign): ?>
                <button type="button" data-modal-open="reassign-technician"
                        class="rounded-md bg-brand px-4 py-2.5 text-xs font-medium text-white hover:bg-blue-700">Reassign Technician</button>
            <?php else: ?>
                <button type="button" disabled title="Cancelled work orders cannot be reassigned"
                        class="cursor-not-allowed rounded-md bg-brand/50 px-4 py-2.5 text-xs font-medium text-white">Reassign Technician</button>
            <?php endif; ?>
        </div>
    </div>

    <div class="grid grid-cols-1 gap-[22px] xl:grid-cols-[736fr_402fr]">
        
        <div class="flex min-w-0 flex-col gap-[18px]">
            <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                <h2 class="text-[15px] font-semibold leading-[1.45]">Work order details</h2>

                <div class="flex gap-2">
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $order->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalb3f3930a96171a12366c9551b2dd3c07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3f3930a96171a12366c9551b2dd3c07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.priority-badge','data' => ['priority' => $order->priority]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('priority-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['priority' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->priority)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3f3930a96171a12366c9551b2dd3c07)): ?>
<?php $attributes = $__attributesOriginalb3f3930a96171a12366c9551b2dd3c07; ?>
<?php unset($__attributesOriginalb3f3930a96171a12366c9551b2dd3c07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3f3930a96171a12366c9551b2dd3c07)): ?>
<?php $component = $__componentOriginalb3f3930a96171a12366c9551b2dd3c07; ?>
<?php unset($__componentOriginalb3f3930a96171a12366c9551b2dd3c07); ?>
<?php endif; ?>
                </div>

                <div class="grid gap-5 sm:grid-cols-2">
                    <div class="leading-[1.6]">
                        <p class="text-[10px] text-muted">Related report</p>
                        <p class="text-xs font-medium"><?php echo e($report->reference_no); ?> · <?php echo e($report->title); ?></p>
                    </div>
                    <div class="leading-[1.6]">
                        <p class="text-[10px] text-muted">Location</p>
                        <p class="text-xs font-medium"><?php echo e($report->placeLabel()); ?></p>
                    </div>
                </div>

                <div class="leading-[1.45]">
                    <p class="text-xs font-semibold">Repair instructions</p>
                    <p class="mt-3.5 whitespace-pre-line text-xs"><?php echo e($order->instructions); ?></p>
                </div>

                <div class="grid gap-5 sm:grid-cols-2">
                    <div class="leading-[1.6]">
                        <p class="text-[10px] text-muted">Assigned by / Date</p>
                        <p class="text-xs font-medium"><?php echo e($order->creator?->name ?? 'Administrator'); ?> · <?php echo e($order->created_at->format('j M Y, g:i A')); ?></p>
                    </div>
                    <div class="leading-[1.6]">
                        <p class="text-[10px] text-muted">Target completion</p>
                        <p class="text-xs font-medium"><?php echo e($order->target_at->format('j M Y · g:i A')); ?></p>
                    </div>
                </div>

                <?php if($isCompleted): ?>
                    <div class="flex items-start gap-2.5 rounded-md bg-[#e8f7f3] p-3 text-[#0f9d8a]">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'circle-check','size' => 18,'class' => 'mt-px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'circle-check','size' => 18,'class' => 'mt-px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <div class="leading-[1.5]">
                            <p class="text-xs font-semibold">
                                <?php echo e($order->progress); ?>% complete · <?php echo e($order->reviewed_at ? 'Reviewed by administrator' : 'Awaiting administrator review'); ?>

                            </p>
                            <p class="text-[11px]">
                                Completed <?php echo e($order->completed_at?->format('j M Y, g:i A')); ?>.
                                <?php if($report->status === \App\Enums\ReportStatus::Resolved): ?> Original incident marked Resolved. <?php endif; ?>
                            </p>
                        </div>
                    </div>
                <?php endif; ?>
            </section>

            <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                <h2 class="text-[15px] font-semibold leading-[1.45]">Repair updates &amp; completion</h2>

                <div class="flex flex-col gap-[18px]">
                    <?php $__empty_1 = true; $__currentLoopData = $order->updates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex gap-4">
                            <div class="flex w-[130px] shrink-0 flex-col items-start gap-1.5">
                                <p class="whitespace-nowrap text-[10px] leading-[1.45] text-muted"><?php echo e($update->created_at->format('j M · g:i A')); ?></p>
                                <?php if($statusEnum = $update->statusEnum()): ?>
                                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $statusEnum]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statusEnum)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <p class="min-w-0 flex-1 text-xs leading-[1.45]"><?php echo e($update->note); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-xs text-muted">No repair updates yet.</p>
                    <?php endif; ?>
                </div>

                <?php if($evidenceOk): ?>
                    <a href="<?php echo e($order->evidence_url); ?>" target="_blank" rel="noopener noreferrer"
                       class="text-[11px] font-medium text-brand hover:underline">
                        <?php echo e($order->evidence_name ? $order->evidence_name . ' · ' : ''); ?>Completion evidence · <?php echo e($evidenceSource); ?> ↗
                    </a>
                <?php endif; ?>
            </section>
        </div>

        
        <div class="flex min-w-0 flex-col gap-[18px]">
            <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                <h2 class="text-[15px] font-semibold leading-[1.45]">Assigned technician</h2>

                <div class="leading-[1.6]">
                    <p class="text-[10px] text-muted">Staff ID / Name</p>
                    <p class="text-xs font-medium"><?php echo e($order->technician->staff_id); ?> · <?php echo e($order->technician->name); ?></p>
                </div>
                <div class="leading-[1.6]">
                    <p class="text-[10px] text-muted">Specialization</p>
                    <p class="text-xs font-medium"><?php echo e($order->technician->specialization ?: $order->technician->specialty); ?></p>
                </div>
                <div class="leading-[1.6]">
                    <p class="text-[10px] text-muted">Contact</p>
                    <p class="text-xs font-medium">
                        <?php echo e($order->technician->email ?: '—'); ?><?php if($order->technician->phone): ?> · <?php echo e($order->technician->phone); ?><?php endif; ?>
                    </p>
                </div>

                <a href="<?php echo e($profileUrl); ?>" class="text-[11px] font-medium text-brand hover:underline">View personnel profile →</a>
            </section>

            <section class="flex flex-col gap-3.5 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]">
                <h2 class="text-[15px] font-semibold leading-[1.45]">Internal notes</h2>

                <?php $__empty_1 = true; $__currentLoopData = $order->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="leading-[1.45]">
                        <p class="whitespace-pre-line text-xs"><?php echo e($note->body); ?></p>
                        <p class="mt-1 text-[10px] text-muted"><?php echo e($note->user?->name ?? 'Administrator'); ?> · <?php echo e($note->created_at->format('j M, g:i A')); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-xs text-muted">No internal notes yet.</p>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.work-orders.notes.store', $order)); ?>" class="flex flex-col gap-3.5">
                    <?php echo csrf_field(); ?>
                    <?php if (isset($component)) { $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.textarea','data' => ['name' => 'body','label' => 'Add administrative note','rows' => '3','maxlength' => '1000','placeholder' => 'Document a follow-up or review note...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'body','label' => 'Add administrative note','rows' => '3','maxlength' => '1000','placeholder' => 'Document a follow-up or review note...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $attributes = $__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__attributesOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886)): ?>
<?php $component = $__componentOriginal4727f9fd7c3055c2cf9c658d89b16886; ?>
<?php unset($__componentOriginal4727f9fd7c3055c2cf9c658d89b16886); ?>
<?php endif; ?>
                    <button type="submit"
                            class="h-9 w-full rounded-md border border-line bg-white text-[11px] font-semibold text-ink hover:bg-canvas">Save Note</button>
                </form>
            </section>
        </div>
    </div>

    
    <?php if($canReassign): ?>
        <dialog id="reassign-technician" data-modal <?php if($errors->has('technician_id')): ?> data-autoopen <?php endif; ?>
                class="m-auto w-[480px] max-w-[calc(100vw-2rem)] rounded-xl bg-white p-0 text-ink shadow-[0_18px_60px_rgba(11,27,51,0.15)] backdrop:bg-[rgba(11,27,51,0.6)]">
            <form method="POST" action="<?php echo e(route('admin.work-orders.reassign', $order)); ?>" class="flex flex-col gap-5 p-7">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <div class="flex items-start justify-between gap-4">
                    <div class="flex flex-col gap-[5px] leading-[1.45]">
                        <h2 class="text-xl font-semibold">Reassign Technician</h2>
                        <p class="text-xs text-muted">Currently assigned to <?php echo e($order->technician->name); ?>.</p>
                    </div>
                    <button type="button" data-modal-close class="text-muted hover:text-ink" aria-label="Close"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'x','size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x','size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
                </div>

                <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'technician_id','label' => 'New technician','required' => true,'submit' => false,'width' => 'w-full','options' => $assignee,'selected' => old('technician_id')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'technician_id','label' => 'New technician','required' => true,'submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'width' => 'w-full','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($assignee),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('technician_id'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>

                <?php if($order->status->isOpen()): ?>
                    <div class="flex items-start gap-2.5 rounded-md bg-[#eff6ff] p-3 text-[#2563eb]">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'info','size' => 17,'class' => 'mt-px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'info','size' => 17,'class' => 'mt-px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <p class="text-[11px] leading-normal">The new technician will need to accept this work order again. The change is recorded in the activity log.</p>
                    </div>
                <?php endif; ?>

                <div class="flex justify-end gap-2.5">
                    <button type="button" data-modal-close
                            class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Cancel</button>
                    <button type="submit" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700">Reassign</button>
                </div>
            </form>
        </dialog>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/work-orders/show.blade.php ENDPATH**/ ?>