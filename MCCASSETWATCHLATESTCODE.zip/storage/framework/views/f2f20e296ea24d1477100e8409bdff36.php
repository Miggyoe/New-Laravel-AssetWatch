
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['user', 'size' => 32]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['user', 'size' => 32]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $url     = $user?->avatarUrl();
    $initial = mb_strtoupper(mb_substr((string) ($user?->name ?? '?'), 0, 1));
?>

<?php if($url): ?>
    <img src="<?php echo e($url); ?>" alt="<?php echo e($user->name); ?>" width="<?php echo e($size); ?>" height="<?php echo e($size); ?>" loading="lazy"
         style="width: <?php echo e($size); ?>px; height: <?php echo e($size); ?>px"
         <?php echo e($attributes->merge(['class' => 'shrink-0 rounded-full object-cover'])); ?>>
<?php else: ?>
    <span style="width: <?php echo e($size); ?>px; height: <?php echo e($size); ?>px; font-size: <?php echo e(max(10, round($size * 0.34))); ?>px"
          <?php echo e($attributes->merge(['class' => 'flex shrink-0 items-center justify-center rounded-full bg-[#e8f0fb] font-semibold text-navy'])); ?>><?php echo e($initial); ?></span>
<?php endif; ?>
<?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/components/avatar.blade.php ENDPATH**/ ?>