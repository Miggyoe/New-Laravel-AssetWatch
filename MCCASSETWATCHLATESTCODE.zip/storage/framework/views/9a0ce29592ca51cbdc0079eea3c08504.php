<?php
    /** @var \App\Models\Category|null $category */
    $id     = $category ? 'edit-category-' . $category->id : 'add-category';
    $reopen = ($openModal ?? null) === $id;
    $val    = fn (string $key) => $reopen ? old($key) : $category?->{$key};
    $input  = 'h-10 w-full rounded-md border bg-white px-3.5 text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/30';
    $err    = fn (string $key) => $reopen ? $errors->first($key) : null;
    $active = $reopen ? (bool) old('is_active') : ($category?->is_active ?? true);
?>

<?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => $id,'title' => $category ? 'Edit category' : 'Add category','subtitle' => $category ? $category->name : 'Group assets and incidents so reports can be analysed by type.','width' => 520,'open' => $reopen]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($id),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category ? 'Edit category' : 'Add category'),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category ? $category->name : 'Group assets and incidents so reports can be analysed by type.'),'width' => 520,'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reopen)]); ?>
    <form method="POST" action="<?php echo e($category ? route('admin.categories.update', $category) : route('admin.categories.store')); ?>" class="flex flex-col gap-4">
        <?php echo csrf_field(); ?>
        <?php if($category): ?> <?php echo method_field('PATCH'); ?> <?php endif; ?>
        <input type="hidden" name="_modal" value="<?php echo e($id); ?>">

        <div>
            <label for="<?php echo e($id); ?>-name" class="mb-[7px] block text-xs font-medium">Category name *</label>
            <input id="<?php echo e($id); ?>-name" name="name" value="<?php echo e($val('name')); ?>" required maxlength="80" placeholder="e.g. Furniture"
                   class="<?php echo e($input); ?> <?php echo e($err('name') ? 'border-red-400' : 'border-line'); ?>">
            <?php if($err('name')): ?> <p class="mt-1 text-[10px] text-[#b91c1c]"><?php echo e($err('name')); ?></p> <?php endif; ?>
        </div>

        <div>
            <label for="<?php echo e($id); ?>-description" class="mb-[7px] block text-xs font-medium">Description</label>
            <input id="<?php echo e($id); ?>-description" name="description" value="<?php echo e($val('description')); ?>" maxlength="200" placeholder="Chairs, desks, cabinets and similar items"
                   class="<?php echo e($input); ?> border-line">
        </div>

        <label class="flex items-center gap-2 text-xs"><input type="checkbox" name="is_active" value="1" class="size-3.5 accent-brand" <?php if($active): echo 'checked'; endif; ?>> Active (shown in new report forms)</label>

        <div class="flex justify-end gap-2.5">
            <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Cancel</button>
            <button type="submit" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700"><?php echo e($category ? 'Save Changes' : 'Add Category'); ?></button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/categories/_form.blade.php ENDPATH**/ ?>