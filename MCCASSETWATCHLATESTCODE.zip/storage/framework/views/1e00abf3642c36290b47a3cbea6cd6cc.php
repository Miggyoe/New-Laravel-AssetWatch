<?php
    /** @var \App\Models\Location|null $room */
    $id     = $room ? 'edit-room-' . $room->id : 'add-room';
    $reopen = ($openModal ?? null) === $id;
    $val    = fn (string $key) => $reopen ? old($key) : $room?->{$key};
    $input  = 'h-10 w-full rounded-md border bg-white px-3.5 text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/30';
    $err    = fn (string $key) => $reopen ? $errors->first($key) : null;
    $listId = 'floors-' . $id;
?>

<?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => $id,'title' => $room ? 'Edit room' : 'Add room','subtitle' => $room ? $room->fullLabel() : 'Room details for ' . $building->name,'width' => 560,'open' => $reopen]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($id),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($room ? 'Edit room' : 'Add room'),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($room ? $room->fullLabel() : 'Room details for ' . $building->name),'width' => 560,'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reopen)]); ?>
    <form method="POST"
          action="<?php echo e($room ? route('admin.locations.rooms.update', [$building, $room]) : route('admin.locations.rooms.store', $building)); ?>"
          class="flex flex-col gap-4">
        <?php echo csrf_field(); ?>
        <?php if($room): ?> <?php echo method_field('PATCH'); ?> <?php endif; ?>
        <input type="hidden" name="_modal" value="<?php echo e($id); ?>">

        <div class="flex flex-col gap-4 sm:flex-row">
            <div class="sm:w-[170px]">
                <label for="<?php echo e($id); ?>-code" class="mb-[7px] block text-xs font-medium">Room code</label>
                <input id="<?php echo e($id); ?>-code" name="code" value="<?php echo e($val('code')); ?>" maxlength="40" placeholder="e.g. MB101"
                       class="<?php echo e($input); ?> <?php echo e($err('code') ? 'border-red-400' : 'border-line'); ?>">
                <?php if($err('code')): ?> <p class="mt-1 text-[10px] text-[#b91c1c]"><?php echo e($err('code')); ?></p> <?php endif; ?>
            </div>
            <div class="flex-1">
                <label for="<?php echo e($id); ?>-name" class="mb-[7px] block text-xs font-medium">Room name *</label>
                <input id="<?php echo e($id); ?>-name" name="name" value="<?php echo e($val('name')); ?>" required maxlength="120" placeholder="e.g. MIS Office"
                       class="<?php echo e($input); ?> <?php echo e($err('name') ? 'border-red-400' : 'border-line'); ?>">
                <?php if($err('name')): ?> <p class="mt-1 text-[10px] text-[#b91c1c]"><?php echo e($err('name')); ?></p> <?php endif; ?>
            </div>
        </div>

        <div class="flex flex-col gap-4 sm:flex-row">
            <div class="sm:w-[200px]">
                <label for="<?php echo e($id); ?>-type" class="mb-[7px] block text-xs font-medium">Type *</label>
                <div class="relative">
                    <select id="<?php echo e($id); ?>-type" name="type" class="<?php echo e($input); ?> appearance-none border-line pr-9">
                        <?php $__currentLoopData = $options['types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type); ?>" <?php if(($val('type') ?? 'Classroom') === $type): echo 'selected'; endif; ?>><?php echo e($type); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="flex-1">
                <label for="<?php echo e($id); ?>-floor" class="mb-[7px] block text-xs font-medium">Floor</label>
                <input id="<?php echo e($id); ?>-floor" name="floor" value="<?php echo e($val('floor')); ?>" list="<?php echo e($listId); ?>" maxlength="80" placeholder="e.g. 1st Floor" class="<?php echo e($input); ?> border-line">
                <datalist id="<?php echo e($listId); ?>">
                    <?php $__currentLoopData = $floors->merge(['1st Floor', '2nd Floor', '3rd Floor'])->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($floor); ?>"></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </datalist>
            </div>
        </div>

        <div>
            <label for="<?php echo e($id); ?>-notes" class="mb-[7px] block text-xs font-medium">Notes</label>
            <input id="<?php echo e($id); ?>-notes" name="notes" value="<?php echo e($val('notes')); ?>" maxlength="200" placeholder="Optional detail, e.g. Service counter" class="<?php echo e($input); ?> border-line">
        </div>

        <div class="flex justify-end gap-2.5">
            <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Cancel</button>
            <button type="submit" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700"><?php echo e($room ? 'Save Changes' : 'Add Room'); ?></button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/locations/_room-form.blade.php ENDPATH**/ ?>