<?php $__env->startSection('title', 'Analytics and Reports'); ?>
<?php $__env->startSection('breadcrumb', 'Analytics and Reports'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $card = 'rounded-[10px] border border-line bg-white shadow-[0_2px_3px_rgba(23,54,93,0.02)]';
        $ghost = 'flex h-9 items-center rounded-md border border-line bg-white px-3.5 text-[11px] font-semibold text-ink hover:bg-canvas';
        $exportUrl = route('admin.analytics.export', $queryString);

        // Monthly stacked bars (viewBox 340 x 190)
        $maxMonth = max(1, collect($months)->max('total'));
        $slot     = 320 / max(1, count($months));
        $barW     = min(36, $slot * 0.55);
        $barH     = 125;
        $base     = 165;

        $topCategory = max(1, $categories->first()['count'] ?? 1);
        $topBuilding = max(1, $buildings->first()['count'] ?? 1);

        $activeOrders = $technicians->sum('active_orders_count');
        $completed    = $technicians->sum('completed_count');
    ?>

    
    <style>
        @media print {
            #sidebar, header, [data-print-hide] { display: none !important; }
            body { background: #fff !important; }
            * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
    </style>

    
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-col gap-[5px]">
            <h1 class="text-[26px] font-semibold leading-[1.45]">Analytics and Reports</h1>
            <p class="text-xs text-muted">Understand recurring facility issues and plan campus maintenance with confidence.</p>
        </div>
        <details data-menu data-print-hide class="relative">
            <summary class="flex cursor-pointer list-none items-center gap-1.5 rounded-md bg-brand px-4 py-2.5 text-xs font-medium text-white hover:bg-blue-700 [&::-webkit-details-marker]:hidden">
                Export Report <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-down','size' => 14]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','size' => 14]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            </summary>
            <div data-menu-panel class="absolute right-0 top-11 z-20 w-48 rounded-md border border-line bg-white py-1 text-[11px] text-ink shadow-lg">
                <button type="button" onclick="window.print()" class="block w-full px-3 py-2 text-left hover:bg-canvas">Print or save as PDF</button>
                <a href="<?php echo e($exportUrl); ?>" class="block px-3 py-2 hover:bg-canvas">Download CSV data</a>
            </div>
        </details>
    </div>

    
    <form method="GET" action="<?php echo e(route('admin.analytics')); ?>" data-print-hide class="flex flex-wrap items-center gap-3">
        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'period','options' => $options['period'],'selected' => $filters['period'],'submit' => false,'width' => 'w-full sm:w-[190px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'period','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['period']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['period']),'submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'width' => 'w-full sm:w-[190px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'building_id','options' => $options['building'],'selected' => $filters['building_id'],'submit' => false,'width' => 'w-full sm:w-[190px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'building_id','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['building']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['building_id']),'submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'width' => 'w-full sm:w-[190px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
        <button type="submit" class="<?php echo e($ghost); ?>">Apply filters</button>
        <p class="text-[11px] text-muted">Current snapshot · <?php echo e(number_format($total)); ?> <?php echo e(\Illuminate\Support\Str::plural('report', $total)); ?></p>

        <div class="ml-auto flex gap-2.5">
            <button type="button" onclick="window.print()" class="<?php echo e($ghost); ?>">PDF report</button>
            <a href="<?php echo e($exportUrl); ?>" class="<?php echo e($ghost); ?>">CSV data</a>
        </div>
    </form>

    
    <div class="grid grid-cols-1 gap-3.5 md:grid-cols-3">
        <div class="relative flex flex-col gap-2 p-4 <?php echo e($card); ?>">
            <p class="text-[11px] text-muted">Total incidents</p>
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'clipboard-list','size' => 18,'class' => 'absolute right-4 top-4 text-brand']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'clipboard-list','size' => 18,'class' => 'absolute right-4 top-4 text-brand']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <div class="flex items-end justify-between gap-2">
                <p class="text-[30px] font-semibold leading-[1.3]"><?php echo e(number_format($total)); ?></p>
                <p class="text-[10px] text-muted"><?php echo e($periodNote); ?></p>
            </div>
        </div>

        <div class="relative flex flex-col gap-2 p-4 <?php echo e($card); ?>">
            <p class="text-[11px] text-muted">Average repair turnaround</p>
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'timer','size' => 18,'class' => 'absolute right-4 top-4 text-teal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'timer','size' => 18,'class' => 'absolute right-4 top-4 text-teal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <div class="flex items-end justify-between gap-2">
                <p class="text-[30px] font-semibold leading-[1.3]"><?php echo e($turnaround === null ? '—' : $turnaround . ' days'); ?></p>
                <?php if($turnaroundDelta !== null): ?>
                    <p class="text-[10px] text-muted"><?php echo e($turnaroundDelta <= 0 ? '↓' : '↑'); ?> <?php echo e(abs($turnaroundDelta)); ?> vs prior period</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="relative flex flex-col gap-2 p-4 <?php echo e($card); ?>">
            <p class="text-[11px] text-muted">Resolved / Unresolved</p>
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'circle-check','size' => 18,'class' => 'absolute right-4 top-4 text-teal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'circle-check','size' => 18,'class' => 'absolute right-4 top-4 text-teal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <div class="flex items-end justify-between gap-2">
                <p class="text-[30px] font-semibold leading-[1.3]"><?php echo e(number_format($resolved)); ?> / <?php echo e(number_format($unresolved)); ?></p>
                <p class="text-[10px] text-muted">Includes <?php echo e(number_format($rejected)); ?> rejected</p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 gap-3.5 xl:grid-cols-[360fr_246fr_221fr]">
        
        <section class="flex min-w-0 flex-col gap-2.5 self-start p-4 <?php echo e($card); ?>">
            <div class="leading-[1.45]">
                <h2 class="text-sm font-semibold">Monthly incidents &amp; resolution</h2>
                <p class="text-[10px] text-muted">Count of reports · resolved versus unresolved</p>
            </div>
            <div class="flex gap-4 text-[10px] text-muted">
                <span class="flex items-center gap-1.5"><span class="size-2 rounded-full bg-teal"></span>Resolved</span>
                <span class="flex items-center gap-1.5"><span class="size-2 rounded-full bg-brand"></span>Unresolved</span>
            </div>

            <svg viewBox="0 0 340 190" class="h-auto w-full" role="img" aria-label="Reports per month, resolved versus unresolved">
                <line x1="0" x2="340" y1="<?php echo e($base); ?>" y2="<?php echo e($base); ?>" stroke="#e2e8f0" />
                <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $x   = 10 + $i * $slot + ($slot - $barW) / 2;
                        $hR  = $month['resolved'] / $maxMonth * $barH;
                        $hU  = $month['unresolved'] / $maxMonth * $barH;
                        $mid = $x + $barW / 2;
                    ?>
                    <?php if($month['total'] > 0): ?>
                        <rect x="<?php echo e(round($x, 1)); ?>" y="<?php echo e(round($base - $hR, 1)); ?>" width="<?php echo e(round($barW, 1)); ?>" height="<?php echo e(round($hR, 1)); ?>" fill="#0f9d8a" />
                        <rect x="<?php echo e(round($x, 1)); ?>" y="<?php echo e(round($base - $hR - $hU, 1)); ?>" width="<?php echo e(round($barW, 1)); ?>" height="<?php echo e(round($hU, 1)); ?>" rx="2" fill="#2563eb" />
                        <text x="<?php echo e(round($mid, 1)); ?>" y="<?php echo e(round($base - $hR - $hU - 6, 1)); ?>" text-anchor="middle" font-size="10" fill="#64748b"><?php echo e($month['total']); ?></text>
                    <?php endif; ?>
                    <text x="<?php echo e(round($mid, 1)); ?>" y="182" text-anchor="middle" font-size="10" fill="#64748b"><?php echo e($month['label']); ?></text>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </svg>
        </section>

        
        <section class="flex min-w-0 flex-col gap-3 p-4 <?php echo e($card); ?>">
            <div class="leading-[1.45]">
                <h2 class="text-sm font-semibold">Most reported asset categories</h2>
                <p class="text-[10px] text-muted">All reports · <?php echo e($categories->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('category', $categories->count())); ?></p>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex flex-col gap-1.5">
                    <div class="flex items-center justify-between text-[11px]"><span><?php echo e($row['label']); ?></span><span class="font-semibold"><?php echo e(number_format($row['count'])); ?></span></div>
                    <div class="h-[5px] rounded-full bg-[#e2e8f0]"><div class="h-full rounded-full bg-brand" style="width: <?php echo e(max(3, round($row['count'] / $topCategory * 100))); ?>%"></div></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-[11px] text-muted">No reports in this period.</p>
            <?php endif; ?>
        </section>

        
        <section class="flex min-w-0 flex-col gap-3 p-4 <?php echo e($card); ?>">
            <div class="leading-[1.45]">
                <h2 class="text-sm font-semibold">Building incident frequency</h2>
                <p class="text-[10px] text-muted">All reports · Ranked by building</p>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex flex-col gap-1.5">
                    <div class="flex items-center justify-between text-[11px]"><span class="truncate pr-2"><?php echo e($row['label']); ?></span><span class="font-semibold"><?php echo e(number_format($row['count'])); ?></span></div>
                    <div class="h-[5px] rounded-full bg-[#e2e8f0]"><div class="h-full rounded-full bg-brand" style="width: <?php echo e(max(3, round($row['count'] / $topBuilding * 100))); ?>%"></div></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-[11px] text-muted">No reports in this period.</p>
            <?php endif; ?>
        </section>
    </div>

    
    <div class="grid grid-cols-1 gap-3.5 xl:grid-cols-[318fr_538fr]">
        <section class="flex min-w-0 flex-col gap-3.5 self-start p-4 <?php echo e($card); ?>">
            <h2 class="text-sm font-semibold leading-[1.45]">Report status distribution</h2>
            <div class="flex flex-wrap items-center gap-5">
                <div class="relative size-[132px] shrink-0">
                    <svg viewBox="0 0 156 156" class="size-full -rotate-90" aria-hidden="true">
                        <circle cx="78" cy="78" r="69" fill="none" stroke="#e2e8f0" stroke-width="18" />
                        <?php $__currentLoopData = $donut['segments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($segment['count'] > 0): ?>
                                <circle cx="78" cy="78" r="69" fill="none" stroke="<?php echo e($segment['status']->color()); ?>" stroke-width="18"
                                        stroke-dasharray="<?php echo e($segment['dash']); ?> <?php echo e($donut['circumference']); ?>" stroke-dashoffset="<?php echo e($segment['offset']); ?>" />
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </svg>
                    <div class="absolute inset-0 flex flex-col items-center justify-center">
                        <p class="text-[24px] font-semibold leading-[1.3]"><?php echo e(number_format($total)); ?></p>
                        <p class="text-[9px] text-muted">Total reports</p>
                    </div>
                </div>
                <ul class="flex min-w-[120px] flex-1 flex-col gap-2.5">
                    <?php $__currentLoopData = $donut['segments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex items-center justify-between text-[11px]">
                            <span class="flex items-center gap-[7px] text-muted"><span class="size-[7px] rounded-full" style="background: <?php echo e($segment['status']->color()); ?>"></span><?php echo e($segment['status']->label()); ?></span>
                            <span class="font-semibold"><?php echo e(number_format($segment['count'])); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </section>

        <section class="min-w-0 <?php echo e($card); ?>">
            <div class="p-4 pb-3 leading-[1.45]">
                <h2 class="text-sm font-semibold">Technician workload &amp; completions</h2>
                <p class="text-[10px] text-muted"><?php echo e(number_format($activeOrders)); ?> active orders · <?php echo e(number_format($completed)); ?> completed in selected period</p>
            </div>
            <div class="overflow-x-auto px-4 pb-4">
                <table class="w-full min-w-[460px] text-left">
                    <thead>
                        <tr class="h-[38px] bg-canvas text-[10px] font-semibold text-muted">
                            <th class="pl-3.5 font-semibold">Technician</th>
                            <th class="px-2 font-semibold">Active orders</th>
                            <th class="px-2 font-semibold">Completed</th>
                            <th class="px-2 font-semibold">On time</th>
                        </tr>
                    </thead>
                    <tbody class="text-[11px]">
                        <?php $__empty_1 = true; $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="h-[34px] border-b border-line last:border-b-0">
                                <td class="pl-3.5 pr-2"><?php echo e($tech->name); ?></td>
                                <td class="px-2"><?php echo e($tech->active_orders_count); ?></td>
                                <td class="px-2"><?php echo e($tech->completed_count); ?></td>
                                <td class="px-2"><?php echo e($tech->completed_count ? round($tech->on_time_count / $tech->completed_count * 100) . '%' : '—'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" class="px-3.5 py-6 text-center text-muted">No active maintenance personnel.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/analytics/index.blade.php ENDPATH**/ ?>