<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('breadcrumb', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $card  = 'scroll-mt-6 rounded-[10px] border border-line bg-white p-5 shadow-[0_2px_3px_rgba(23,54,93,0.02)]';
        $input = 'h-10 w-full rounded-md border border-line bg-white px-3.5 text-xs text-ink focus:outline-none focus:ring-2 focus:ring-brand/30';
        $label = 'mb-[7px] block text-xs font-medium';
        $nav   = [
            ['Administrator profile', '#profile'],
            ['Account management',    '#roles'],
            ['Roles & permissions',   '#roles'],
            ['Notifications',         '#notifications'],
            ['Campus information',    '#campus'],
            ['System configuration',  '#system'],
        ];
        $permissions = [
            ['Verify / reject reports',               'Allowed', 'Not allowed'],
            ['Create / reassign work orders',         'Allowed', 'Not allowed'],
            ['Update repair progress & evidence',     'Allowed', 'Assigned jobs only'],
            ['Manage personnel & configuration',      'Allowed', 'Not allowed'],
            ['View original evidence',                'All reports', 'Assigned jobs only'],
        ];
    ?>

    
    <div class="flex flex-wrap items-start justify-between gap-3">
        <div class="flex flex-col gap-[5px]">
            <h1 class="text-[26px] font-semibold leading-[1.45]">Settings</h1>
            <p class="text-xs text-muted">Manage your profile, access policies, and campus preferences.</p>
        </div>
        <button type="submit" form="settings-form" class="rounded-md bg-brand px-4 py-2.5 text-xs font-medium text-white hover:bg-blue-700">Save Changes</button>
    </div>

    <div class="grid grid-cols-1 gap-5 lg:grid-cols-[148px_minmax(0,1fr)]">
        
        <aside class="flex flex-col gap-3 self-start lg:sticky lg:top-6">
            <nav class="flex flex-row flex-wrap gap-1 lg:flex-col">
                <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$text, $href]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($href); ?>" data-settings-link
                       class="flex h-9 items-center rounded-md px-3 text-xs <?php echo e($i === 0 ? 'bg-[#eff6ff] font-medium text-brand' : 'text-slate-600 hover:bg-white'); ?>"><?php echo e($text); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
            <p class="hidden px-1 text-[10px] leading-[1.45] text-muted lg:block">Administrator-only configuration. Technicians manage their own profile and task notifications.</p>
        </aside>

        <form id="settings-form" method="POST" action="<?php echo e(route('admin.settings.update')); ?>" class="min-w-0">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                
                <section id="profile" class="flex flex-col gap-3.5 <?php echo e($card); ?>">
                    <h2 class="text-[15px] font-semibold leading-[1.45]">Administrator profile</h2>
                    <div class="grid grid-cols-2 gap-3">
                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'first_name','label' => 'First name','value' => $firstName,'required' => true,'maxlength' => '60']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'first_name','label' => 'First name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($firstName),'required' => true,'maxlength' => '60']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'last_name','label' => 'Last name','value' => $lastName,'maxlength' => '60']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'last_name','label' => 'Last name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($lastName),'maxlength' => '60']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                    </div>
                    <div>
                        <label class="<?php echo e($label); ?>">Institutional email</label>
                        <input type="email" value="<?php echo e($user->email); ?>" disabled class="<?php echo e($input); ?> cursor-not-allowed bg-canvas text-muted">
                    </div>
                    <a href="https://mysignins.microsoft.com/security-info" target="_blank" rel="noopener noreferrer" class="w-fit text-[11px] font-medium text-brand hover:underline">Change password →</a>
                </section>

                
                <section id="campus" class="flex flex-col gap-3.5 <?php echo e($card); ?>">
                    <h2 class="text-[15px] font-semibold leading-[1.45]">Campus information</h2>
                    <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'institution','label' => 'Institution','value' => $campus['institution'],'required' => true,'maxlength' => '120']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'institution','label' => 'Institution','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($campus['institution']),'required' => true,'maxlength' => '120']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="<?php echo e($label); ?>">Timezone</label>
                            <div class="relative">
                                <select disabled class="<?php echo e($input); ?> cursor-not-allowed appearance-none bg-canvas pr-9 text-muted"><option><?php echo e($campus['timezone']); ?></option></select>
                                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'helpdesk_extension','label' => 'Helpdesk extension','value' => $campus['extension'],'maxlength' => '20']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'helpdesk_extension','label' => 'Helpdesk extension','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($campus['extension']),'maxlength' => '20']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                    </div>
                    <p class="text-[10px] leading-[1.45] text-muted">Campus details appear in exports and system notices. The timezone follows APP_TIMEZONE in the server configuration.</p>
                </section>

                
                <section id="roles" class="flex flex-col gap-3.5 md:col-span-2 <?php echo e($card); ?>">
                    <div class="leading-[1.45]">
                        <h2 class="text-[15px] font-semibold">Roles &amp; permissions</h2>
                        <p class="text-[10px] text-muted">Access is assigned by authorized administrators.</p>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full min-w-[520px] text-left">
                            <thead>
                                <tr class="h-[42px] bg-canvas text-[10px] font-semibold text-muted">
                                    <th class="w-[44%] pl-4 font-semibold">Permission</th>
                                    <th class="px-2 font-semibold">Administrator</th>
                                    <th class="px-2 font-semibold">Technician</th>
                                </tr>
                            </thead>
                            <tbody class="text-[11px]">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$permission, $admin, $technician]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="h-[34px] border-b border-line last:border-b-0">
                                        <td class="pl-4 pr-2"><?php echo e($permission); ?></td>
                                        <td class="px-2"><?php echo e($admin); ?></td>
                                        <td class="px-2"><?php echo e($technician); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="flex flex-wrap items-center justify-between gap-3 pt-2">
                        <p class="text-[10px] text-muted">
                            <?php echo e($counts['maintenance']); ?> maintenance <?php echo e(\Illuminate\Support\Str::plural('account', $counts['maintenance'])); ?> · <?php echo e($counts['admins']); ?> <?php echo e(\Illuminate\Support\Str::plural('administrator', $counts['admins'])); ?>

                        </p>
                        <a href="<?php echo e(Route::has('admin.users.index') ? route('admin.users.index') : '#'); ?>"
                           class="flex h-9 items-center rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Manage Accounts</a>
                    </div>
                </section>

                
                <section id="notifications" class="flex flex-col gap-3.5 <?php echo e($card); ?>">
                    <h2 class="text-[15px] font-semibold leading-[1.45]">Notification preferences</h2>
                    <div class="flex flex-col gap-3">
                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="flex items-center gap-2.5 text-sm">
                                <input type="checkbox" name="notify[<?php echo e($key); ?>]" value="1" class="size-4 accent-ink" <?php if(old('_token') ? old("notify.$key") : $item['on']): echo 'checked'; endif; ?>>
                                <?php echo e($item['label']); ?>

                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>

                
                <section id="system" class="flex flex-col gap-3.5 <?php echo e($card); ?>">
                    <h2 class="text-[15px] font-semibold leading-[1.45]">System configuration</h2>
                    <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'target_days','label' => 'Default target completion','submit' => false,'width' => 'w-full','options' => $targetOptions,'selected' => old('target_days', $system['target_days'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'target_days','label' => 'Default target completion','submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'width' => 'w-full','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($targetOptions),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('target_days', $system['target_days']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'evidence_limit','label' => 'Evidence attachment limit','value' => $system['evidence'],'maxlength' => '80']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'evidence_limit','label' => 'Evidence attachment limit','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($system['evidence']),'maxlength' => '80']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                    <p class="text-[10px] leading-[1.45] text-muted">Google Drive links are shown as evidence attachments. No storage credentials are displayed.</p>
                </section>
            </div>
        </form>
    </div>

    <script>
        document.querySelectorAll('[data-settings-link]').forEach((link) => link.addEventListener('click', () => {
            document.querySelectorAll('[data-settings-link]').forEach((l) => l.classList.remove('bg-[#eff6ff]', 'font-medium', 'text-brand'));
            link.classList.add('bg-[#eff6ff]', 'font-medium', 'text-brand');
        }));
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>