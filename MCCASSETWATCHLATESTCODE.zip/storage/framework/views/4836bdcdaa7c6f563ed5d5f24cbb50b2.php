<?php
    /** @var \App\Models\User|null $person */
    $id     = $person ? 'edit-user-' . $person->id : 'add-user';
    $reopen = ($openModal ?? null) === $id;
    $val    = fn (string $key, $default = null) => $reopen ? old($key) : ($person?->{$key} ?? $default);
    $input  = 'h-10 w-full rounded-md border bg-white px-3.5 text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/30';
    $err    = fn (string $key) => $reopen ? $errors->first($key) : null;
    $isSelf = $person && $person->is(auth()->user());
?>

<?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => $id,'title' => $person ? 'Edit user' : 'Add user','subtitle' => $person ? $person->email : 'They sign in with their MCC Microsoft account; no password is created.','width' => 520,'open' => $reopen]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($id),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($person ? 'Edit user' : 'Add user'),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($person ? $person->email : 'They sign in with their MCC Microsoft account; no password is created.'),'width' => 520,'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reopen)]); ?>
    <form method="POST" action="<?php echo e($person ? route('admin.users.update', $person) : route('admin.users.store')); ?>" class="flex flex-col gap-4">
        <?php echo csrf_field(); ?>
        <?php if($person): ?> <?php echo method_field('PATCH'); ?> <?php endif; ?>
        <input type="hidden" name="_modal" value="<?php echo e($id); ?>">

        <?php if (! ($person)): ?>
            <?php $__currentLoopData = [['name', 'Full name', 'text'], ['email', 'MCC email', 'email']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, $label, $type]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label for="<?php echo e($id); ?>-<?php echo e($key); ?>" class="mb-[7px] block text-xs font-medium"><?php echo e($label); ?> *</label>
                    <input id="<?php echo e($id); ?>-<?php echo e($key); ?>" type="<?php echo e($type); ?>" name="<?php echo e($key); ?>" value="<?php echo e($val($key)); ?>" required
                           placeholder="<?php echo e($key === 'email' ? 'name@' . ($domains[0] ?? 'mcc.edu.ph') : ''); ?>"
                           class="<?php echo e($input); ?> <?php echo e($err($key) ? 'border-red-400' : 'border-line'); ?>">
                    <?php if($err($key)): ?> <p class="mt-1 text-[10px] text-[#b91c1c]"><?php echo e($err($key)); ?></p> <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <div class="flex flex-col gap-4 sm:flex-row">
            <div class="sm:w-[200px]">
                <label for="<?php echo e($id); ?>-role" class="mb-[7px] block text-xs font-medium">Role *</label>
                <div class="relative">
                    <select id="<?php echo e($id); ?>-role" name="role" <?php if($isSelf): echo 'disabled'; endif; ?> class="<?php echo e($input); ?> appearance-none border-line pr-9 disabled:bg-canvas disabled:text-muted">
                        <?php $__currentLoopData = $options['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(($val('role', 'user')) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','size' => 16,'class' => 'pointer-events-none absolute right-3 top-1/2 -translate-y-1/2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </div>
                <?php if($isSelf): ?>
                    
                    <input type="hidden" name="role" value="<?php echo e($person->role); ?>">
                    <p class="mt-1 text-[10px] text-muted">You cannot change your own role.</p>
                <?php endif; ?>
            </div>
            <div class="flex-1">
                <label for="<?php echo e($id); ?>-department" class="mb-[7px] block text-xs font-medium">Department / position</label>
                <input id="<?php echo e($id); ?>-department" name="department" value="<?php echo e($val('department')); ?>" maxlength="80" placeholder="e.g. Faculty, Facilities Office" class="<?php echo e($input); ?> border-line">
            </div>
        </div>

        <div class="flex justify-end gap-2.5">
            <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Cancel</button>
            <button type="submit" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700"><?php echo e($person ? 'Save Changes' : 'Add User'); ?></button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/users/_form.blade.php ENDPATH**/ ?>