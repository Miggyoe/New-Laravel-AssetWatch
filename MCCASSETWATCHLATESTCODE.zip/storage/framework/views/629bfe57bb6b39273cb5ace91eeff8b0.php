<?php $__env->startSection('title', 'Asset Categories'); ?>
<?php $__env->startSection('breadcrumb', 'Asset Categories'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $heads = ['Category name', 'Description', 'Active reports', 'Actions'];
        $link  = 'font-medium text-brand hover:underline';
    ?>

    
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-col gap-[5px]">
            <h1 class="text-[26px] font-semibold leading-[1.45]">Asset Categories</h1>
            <p class="text-xs text-muted">Keep campus incidents organized with clear, consistent asset classifications.</p>
        </div>
        <div class="flex items-center gap-2.5">
            <p class="text-[11px] text-muted"><?php echo e(number_format($total)); ?> <?php echo e(\Illuminate\Support\Str::plural('category', $total)); ?> · <?php echo e(number_format($activeReports)); ?> active reports</p>
            <button type="button" data-modal-open="add-category" class="rounded-md bg-brand px-4 py-2.5 text-xs font-medium text-white hover:bg-blue-700">Add Category</button>
        </div>
    </div>

    <form method="GET" action="<?php echo e(route('admin.categories.index')); ?>"
          class="rounded-[10px] border border-line bg-white shadow-[0_2px_3px_rgba(23,54,93,0.02)]">

        <div class="flex flex-wrap items-start gap-3 p-[18px]">
            <div class="relative w-full sm:w-[316px]">
                <input type="search" name="q" value="<?php echo e($filters['q']); ?>" placeholder="Search category name or description"
                       class="h-10 w-full rounded-md border border-line bg-white pl-3.5 pr-10 text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/30">
                <button type="submit" class="absolute right-3 top-1/2 -translate-y-1/2 text-ink" aria-label="Search"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','size' => 16]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','size' => 16]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
            </div>
            <p class="pt-1 text-[11px] text-muted">Active report counts exclude resolved and rejected reports.</p>
            <?php if($filters['q']): ?>
                <a href="<?php echo e(route('admin.categories.index')); ?>" class="pt-1 text-[11px] font-medium text-brand hover:underline">Clear search</a>
            <?php endif; ?>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full min-w-[760px] table-fixed text-left">
                <colgroup>
                    <col class="w-[235px]"><col><col class="w-[150px]"><col class="w-[165px]">
                </colgroup>
                <thead>
                    <tr class="h-[43px] bg-canvas text-[10px] font-semibold text-muted">
                        <?php $__currentLoopData = $heads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="<?php echo e($i === 0 ? 'pl-4 pr-2' : 'px-2'); ?> font-semibold"><?php echo e($head); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <?php if($categories->isNotEmpty()): ?>
                    <tbody class="text-[11px]">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $active = $category->is_active ?? true; ?>
                            <tr class="h-[52px] border-b border-line last:border-b-0 hover:bg-canvas/60 <?php echo e($active ? '' : 'bg-canvas/50'); ?>">
                                <td class="pl-4 pr-2">
                                    <span class="text-[11px] font-medium <?php echo e($active ? '' : 'text-muted'); ?>"><?php echo e($category->name); ?></span>
                                    <?php if (! ($active)): ?>
                                        <span class="ml-1.5 inline-flex h-[23px] items-center rounded-full bg-[#f5f7fb] px-2 text-[10px] font-semibold text-[#64748b]">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-2 align-middle leading-[1.45] text-ink"><?php echo e($category->description ?: '—'); ?></td>
                                <td class="px-2 align-middle">
                                    <span class="inline-flex h-[23px] min-w-[28px] items-center justify-center rounded-full bg-[#eff6ff] px-2 text-[10px] font-semibold text-brand"><?php echo e($category->active_reports_count); ?></span>
                                </td>
                                <td class="whitespace-nowrap px-2 align-middle">
                                    <button type="button" data-modal-open="edit-category-<?php echo e($category->id); ?>" class="text-[11px] font-medium text-brand hover:underline">Edit</button>
                                    <span class="text-brand"> · </span>
                                    <button type="submit" form="toggle-category-<?php echo e($category->id); ?>" class="text-[11px] font-medium text-brand hover:underline"><?php echo e($active ? 'Deactivate' : 'Reactivate'); ?></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                <?php endif; ?>
            </table>
        </div>

        <?php if($categories->isEmpty()): ?>
            <div class="flex min-h-[240px] flex-col items-center justify-center gap-3 px-6 py-10 text-center">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search-x','size' => 30,'class' => 'text-muted']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search-x','size' => 30,'class' => 'text-muted']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                <p class="text-base font-semibold leading-[1.45]"><?php echo e($hasFilters ? 'No categories match your search' : 'No categories yet'); ?></p>
                <p class="text-xs text-muted"><?php echo e($hasFilters ? 'Try another keyword.' : 'Add a category so reports can be grouped by type.'); ?></p>
            </div>
        <?php else: ?>
            <?php echo $__env->make('admin.partials.pagination', ['paginator' => $categories], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </form>

    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['tone' => 'blue','icon' => 'info','title' => 'One category per incident','body' => 'Use a clear primary category. Historical category labels remain available for audit and analytics.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'blue','icon' => 'info','title' => 'One category per incident','body' => 'Use a clear primary category. Historical category labels remain available for audit and analytics.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form id="toggle-category-<?php echo e($category->id); ?>" method="POST" action="<?php echo e(route('admin.categories.toggle', $category)); ?>" class="hidden"><?php echo csrf_field(); ?></form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $__env->make('admin.categories._form', ['category' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('admin.categories._form', ['category' => $category], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>