<?php
    /** @var \App\Models\Building|null $building */
    $id     = $building ? 'edit-location-' . $building->id : 'add-location';
    $reopen = ($openModal ?? null) === $id;
    $name   = $reopen ? old('name') : $building?->name;
    $active = $reopen ? (bool) old('is_active') : ($building?->is_active ?? true);
    $error  = $reopen ? $errors->first('name') : null;
?>

<?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => $id,'title' => $building ? 'Edit location' : 'Add location','subtitle' => $building ? $building->name : 'Create the building first, then add its rooms.','width' => 520,'open' => $reopen]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($id),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($building ? 'Edit location' : 'Add location'),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($building ? $building->name : 'Create the building first, then add its rooms.'),'width' => 520,'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reopen)]); ?>
    <form method="POST" action="<?php echo e($building ? route('admin.locations.update', $building) : route('admin.locations.store')); ?>" class="flex flex-col gap-4">
        <?php echo csrf_field(); ?>
        <?php if($building): ?> <?php echo method_field('PATCH'); ?> <?php endif; ?>
        <input type="hidden" name="_modal" value="<?php echo e($id); ?>">

        <div>
            <label for="<?php echo e($id); ?>-name" class="mb-[7px] block text-xs font-medium">Building name *</label>
            <input id="<?php echo e($id); ?>-name" name="name" value="<?php echo e($name); ?>" required maxlength="120" placeholder="e.g. Building 1"
                   class="h-10 w-full rounded-md border bg-white px-3.5 text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 <?php echo e($error ? 'border-red-400' : 'border-line'); ?>">
            <?php if($error): ?> <p class="mt-1 text-[10px] text-[#b91c1c]"><?php echo e($error); ?></p> <?php endif; ?>
        </div>

        <label class="flex items-center gap-2 text-xs"><input type="checkbox" name="is_active" value="1" class="size-3.5 accent-brand" <?php if($active): echo 'checked'; endif; ?>> Active (shown in new report forms)</label>

        <div class="flex justify-end gap-2.5">
            <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Cancel</button>
            <button type="submit" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700"><?php echo e($building ? 'Save Changes' : 'Add Location'); ?></button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/locations/_form.blade.php ENDPATH**/ ?>