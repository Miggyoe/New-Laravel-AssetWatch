<?php $__env->startSection('title', 'Maintenance Personnel'); ?>
<?php $__env->startSection('breadcrumb', 'Maintenance Personnel'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $heads = ['Staff ID', 'Personnel', 'Email', 'Specialization', 'Active orders', 'Availability', 'Account', 'Actions'];
        $accountBadge = fn (bool $active) => $active ? 'bg-[#eaf7ee] text-[#15803d]' : 'bg-[#f5f7fb] text-[#64748b]';
        $pill = 'inline-flex h-[23px] items-center whitespace-nowrap rounded-full px-2 text-[10px] font-semibold';
        $editIds = $people->pluck('id');
    ?>

    
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-col gap-[5px]">
            <h1 class="text-[26px] font-semibold leading-[1.45]">Maintenance Personnel</h1>
            <p class="text-xs text-muted">Manage technician accounts, specializations, availability, and assignments.</p>
        </div>
        <div class="flex items-center gap-2.5">
            <p class="text-[11px] text-muted"><?php echo e(number_format($total)); ?> personnel <?php echo e(\Illuminate\Support\Str::plural('record', $total)); ?></p>
            <button type="button" data-modal-open="add-personnel" class="rounded-md bg-brand px-4 py-2.5 text-xs font-medium text-white hover:bg-blue-700">Add Personnel</button>
        </div>
    </div>

    
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['label' => 'Active personnel','value' => $stats['active'],'note' => 'Across ' . $stats['specialties'] . ' specializations','icon' => 'users','iconClass' => 'text-brand']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Active personnel','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['active']),'note' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Across ' . $stats['specialties'] . ' specializations'),'icon' => 'users','icon-class' => 'text-brand']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['label' => 'Available for assignment','value' => $stats['available'],'note' => 'Under ' . $stats['busy_threshold'] . ' open orders','icon' => 'user-check','iconClass' => 'text-teal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Available for assignment','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['available']),'note' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Under ' . $stats['busy_threshold'] . ' open orders'),'icon' => 'user-check','icon-class' => 'text-teal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['label' => 'Active work orders','value' => $stats['active_orders'],'note' => 'Assigned, accepted, in progress','icon' => 'wrench','iconClass' => 'text-brand']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Active work orders','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['active_orders']),'note' => 'Assigned, accepted, in progress','icon' => 'wrench','icon-class' => 'text-brand']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
    </div>

    <form method="GET" action="<?php echo e(route('admin.personnel.index')); ?>"
          class="rounded-[10px] border border-line bg-white shadow-[0_2px_3px_rgba(23,54,93,0.02)]">

        
        <div class="flex flex-wrap items-center gap-3 p-[18px]">
            <div class="relative w-full sm:w-[260px]">
                <input type="search" name="q" value="<?php echo e($filters['q']); ?>" placeholder="Search name, staff ID, or email"
                       class="h-10 w-full rounded-md border border-line bg-white pl-3.5 pr-10 text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/30">
                <button type="submit" class="absolute right-3 top-1/2 -translate-y-1/2 text-ink" aria-label="Search"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','size' => 16]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','size' => 16]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
            </div>
            <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'specialty','options' => $options['specialty'],'selected' => $filters['specialty'],'width' => 'w-full sm:w-[190px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'specialty','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['specialty']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['specialty']),'width' => 'w-full sm:w-[190px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'availability','options' => $options['availability'],'selected' => $filters['availability'],'width' => 'w-full sm:w-[160px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'availability','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['availability']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['availability']),'width' => 'w-full sm:w-[160px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'account','options' => $options['account'],'selected' => $filters['account'],'width' => 'w-full sm:w-[150px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'account','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options['account']),'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['account']),'width' => 'w-full sm:w-[150px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
            <a href="<?php echo e(route('admin.personnel.index')); ?>" class="flex h-9 items-center rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Reset</a>
        </div>

        
        <div class="overflow-x-auto">
            <table class="w-full min-w-[980px] table-fixed text-left">
                <colgroup>
                    <col class="w-[96px]"><col class="w-[190px]"><col><col class="w-[190px]"><col class="w-[100px]">
                    <col class="w-[112px]"><col class="w-[92px]"><col class="w-[96px]">
                </colgroup>
                <thead>
                    <tr class="h-[43px] bg-canvas text-[10px] font-semibold text-muted">
                        <?php $__currentLoopData = $heads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="<?php echo e($i === 0 ? 'pl-4 pr-2' : 'px-2'); ?> font-semibold"><?php echo e($head); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <?php if($people->isNotEmpty()): ?>
                    <tbody class="text-[11px]">
                        <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $availability = $person->availability(); ?>
                            <tr class="h-[57px] border-b border-line last:border-b-0 hover:bg-canvas/60">
                                <td class="pl-4 pr-2 font-medium text-brand"><?php echo e($person->staff_id); ?></td>
                                <td class="px-2">
                                    <div class="flex items-center gap-2.5">
                                        <span class="flex size-8 shrink-0 items-center justify-center rounded-full bg-[#e8f0fb] text-[11px] font-semibold text-navy"><?php echo e($person->initial()); ?></span>
                                        <span class="min-w-0 truncate font-medium"><?php echo e($person->name); ?></span>
                                    </div>
                                </td>
                                <td class="truncate px-2"><?php echo e($person->email ?: '—'); ?></td>
                                <td class="px-2 leading-[1.4]"><?php echo e($person->specialization ?: $person->specialty); ?></td>
                                <td class="px-2"><?php echo e($person->active_orders_count); ?></td>
                                <td class="px-2"><span class="<?php echo e($pill); ?> <?php echo e($availability->badge()); ?>"><?php echo e($availability->label()); ?></span></td>
                                <td class="px-2"><span class="<?php echo e($pill); ?> <?php echo e($accountBadge($person->is_active)); ?>"><?php echo e($person->is_active ? 'Active' : 'Inactive'); ?></span></td>
                                <td class="whitespace-nowrap px-2 font-medium text-brand">
                                    <div class="flex items-center gap-2">
                                        <a href="<?php echo e(route('admin.personnel.index', array_merge(request()->query(), ['profile' => $person->id]))); ?>" class="hover:underline">Profile</a>
                                        <details data-menu class="relative">
                                            <summary class="flex cursor-pointer list-none items-center rounded p-0.5 hover:bg-canvas [&::-webkit-details-marker]:hidden" aria-label="More actions">
                                                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'ellipsis','size' => 16]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'ellipsis','size' => 16]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                                            </summary>
                                            <div data-menu-panel class="absolute right-0 top-6 z-20 w-48 rounded-md border border-line bg-white py-1 text-[11px] font-normal text-ink shadow-lg">
                                                <button type="button" data-modal-open="edit-personnel-<?php echo e($person->id); ?>" class="block w-full px-3 py-2 text-left hover:bg-canvas"
                                                        onclick="this.closest('details').removeAttribute('open')">Edit personnel</button>
                                                <button type="submit" form="toggle-available-<?php echo e($person->id); ?>" class="block w-full px-3 py-2 text-left hover:bg-canvas">
                                                    <?php echo e($person->is_available ? 'Mark as unavailable' : 'Mark as available'); ?></button>
                                                <button type="submit" form="toggle-active-<?php echo e($person->id); ?>" class="block w-full px-3 py-2 text-left hover:bg-canvas <?php echo e($person->is_active ? 'text-[#b91c1c]' : ''); ?>">
                                                    <?php echo e($person->is_active ? 'Deactivate account' : 'Activate account'); ?></button>
                                            </div>
                                        </details>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                <?php endif; ?>
            </table>
        </div>

        <?php if($people->isEmpty()): ?>
            <div class="flex min-h-[260px] flex-col items-center justify-center gap-3 px-6 py-10 text-center">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search-x','size' => 30,'class' => 'text-muted']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search-x','size' => 30,'class' => 'text-muted']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                <p class="text-base font-semibold leading-[1.45]"><?php echo e($hasFilters ? 'No personnel match your filters' : 'No maintenance personnel yet'); ?></p>
                <p class="text-xs text-muted"><?php echo e($hasFilters ? 'Try another keyword or reset your filters.' : 'Add a technician to start assigning work orders.'); ?></p>
                <?php if($hasFilters): ?>
                    <a href="<?php echo e(route('admin.personnel.index')); ?>" class="mt-2 rounded-md bg-brand px-4 py-2.5 text-[11px] font-semibold text-white hover:bg-blue-700">Reset filters</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <?php echo $__env->make('admin.partials.pagination', ['paginator' => $people], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </form>

    
    <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form id="toggle-active-<?php echo e($person->id); ?>" method="POST" action="<?php echo e(route('admin.personnel.toggle', [$person, 'active'])); ?>" class="hidden"><?php echo csrf_field(); ?></form>
        <form id="toggle-available-<?php echo e($person->id); ?>" method="POST" action="<?php echo e(route('admin.personnel.toggle', [$person, 'available'])); ?>" class="hidden"><?php echo csrf_field(); ?></form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php echo $__env->make('admin.personnel._form', ['technician' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('admin.personnel._form', ['technician' => $person], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($profile && ! $editIds->contains($profile->id)): ?>
        <?php echo $__env->make('admin.personnel._form', ['technician' => $profile], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    
    <?php if($profile): ?>
        <?php $pa = $profile->availability(); ?>
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'personnel-profile','title' => 'Personnel profile','subtitle' => 'Staff contact, assignments, and repair history','width' => 680,'open' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'personnel-profile','title' => 'Personnel profile','subtitle' => 'Staff contact, assignments, and repair history','width' => 680,'open' => true]); ?>
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3.5">
                    <span class="flex size-14 shrink-0 items-center justify-center rounded-full bg-[#e8f0fb] text-xl font-semibold text-navy"><?php echo e($profile->initial()); ?></span>
                    <div class="leading-[1.45]">
                        <p class="text-base font-semibold"><?php echo e($profile->name); ?></p>
                        <p class="text-[11px] text-muted"><?php echo e($profile->staff_id); ?> · <?php echo e($profile->specialization ?: $profile->specialty); ?></p>
                    </div>
                </div>
                <div class="flex gap-2">
                    <span class="<?php echo e($pill); ?> <?php echo e($accountBadge($profile->is_active)); ?>"><?php echo e($profile->is_active ? 'Active' : 'Inactive'); ?></span>
                    <span class="<?php echo e($pill); ?> <?php echo e($pa->badge()); ?>"><?php echo e($pa->label()); ?></span>
                </div>
            </div>

            <div class="flex flex-col gap-4 sm:flex-row sm:gap-6">
                <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Institutional email','value' => $profile->email ?: '—']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Institutional email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profile->email ?: '—')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal92f9ddfc601860764b158da0250aeaf6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92f9ddfc601860764b158da0250aeaf6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail','data' => ['label' => 'Phone','value' => $profile->phone ?: '—']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Phone','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profile->phone ?: '—')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $attributes = $__attributesOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__attributesOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92f9ddfc601860764b158da0250aeaf6)): ?>
<?php $component = $__componentOriginal92f9ddfc601860764b158da0250aeaf6; ?>
<?php unset($__componentOriginal92f9ddfc601860764b158da0250aeaf6); ?>
<?php endif; ?>
            </div>

            <div class="grid grid-cols-3 gap-3">
                <?php $__currentLoopData = [['Active work orders', $profileData['active']], ['Completed repairs', $profileData['completed']], ['On-time completion', $profileData['on_time'] === null ? '—' : $profileData['on_time'] . '%']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $number]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-lg border border-line p-3.5">
                        <p class="text-[10px] text-muted"><?php echo e($label); ?></p>
                        <p class="text-[22px] font-semibold leading-[1.45]"><?php echo e($number); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="flex flex-col gap-2.5">
                <p class="text-xs font-semibold">Assigned work orders &amp; recent repairs</p>
                <?php $__empty_1 = true; $__currentLoopData = $profileData['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between gap-3 border-b border-line pb-2.5 text-[11px] last:border-b-0">
                        <div class="min-w-0">
                            <a href="<?php echo e(route('admin.work-orders.show', $order)); ?>" class="font-medium text-brand hover:underline"><?php echo e($order->reference_no); ?></a>
                            <span class="text-muted"> · <?php echo e($order->title); ?> · <?php echo e($order->report?->locationShort()); ?></span>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $order->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-[11px] text-muted">No work orders yet.</p>
                <?php endif; ?>
            </div>

            <div class="flex flex-col gap-2">
                <p class="text-xs font-semibold">Recent activity</p>
                <?php $__empty_1 = true; $__currentLoopData = $profileData['activity']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <p class="text-[11px] leading-[1.45] text-muted"><?php echo e($entry->created_at->format('j M, g:i A')); ?> · <?php echo e($entry->workOrder?->reference_no); ?> · <?php echo e($entry->note); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-[11px] text-muted">No activity yet.</p>
                <?php endif; ?>
            </div>

            <div class="flex justify-end gap-2.5">
                <button type="button" data-modal-close class="h-9 rounded-md border border-line bg-white px-4 text-[11px] font-semibold text-ink hover:bg-canvas">Close</button>
                <button type="button" data-modal-open="edit-personnel-<?php echo e($profile->id); ?>" class="h-9 rounded-md bg-brand px-4 text-[11px] font-semibold text-white hover:bg-blue-700">Edit Personnel</button>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ETHAN\Programming\3rd_Year\New Laravel assetwatch\mcc-assetwatch\resources\views/admin/personnel/index.blade.php ENDPATH**/ ?>